<?php include 'include/header.php'; 
//mysqli_query($con, "UPDATE border SET total_meal=0");
?>
<style>
  @media print {
     body *:not(.table-wrap) {
        display: none;
      }
    }
</style>
	<section class="ftco-section">
		<div class="container">
			<div class="row">
				<div class="col-md-12">

					<div class="table-wrap">
						<table class="table">
						  <thead class="thead-primary">
						    <tr>
						    	<th>Name</th>
						      <th>Mobile</th>
						        <th>Remaining Tk </th>
						      <th>Gave Tk </th>
						      <th>Profile</th>
						    </tr>
						  </thead>
						  <tbody>
						                                 <?php
						                                 
						                             
						                             foreach(mysqli_query($con,"SELECT meal_rate FROM setting LIMIT 1") as $r){
						          $rate = floatval($r['meal_rate']);
						          }
						          $rate = 40.48;
						          
						               
						                         
						                                 
                             $border =mysqli_query($con,"SELECT * FROM border order by room");

     
                             if(mysqli_num_rows($border) > 0){
                               foreach($border as $row){
                     ?>   
						    <tr class="alert person" role="alert" id="<?= $row['unique_id']?>">
						      <td class="quantity">
					        	<div class="input-group checkbox-wrap text-primary">
					        	  	  <a href="border.php?id=<?= $row['unique_id']?>">
				             	<?= $row['name']?>(<?=$row['room']?>)
				          </a>	</div>
				          </td>
				           <td class="quantity">
					        	<div class="input-group checkbox-wrap text-primary">
				             	<?= $row['mobile'] ?>
				          	</div>
				          </td>
				          
				          <td style="" class="quantity">
					         <?php
				          $remaining = floatval($row['tk']) - floatval($row['total_meal'])*$rate;
				          if($remaining>100){
				         ?>
					         	<div class="input-group checkbox-wrap text-primary ">
					        	  				   <?= $remaining ?>       
					        	  </div>
					        	  <?php }
					        	  else{
					        	 ?>
					        	  	<div class="input-group checkbox-wrap text-danger" style="color:rgb(234,28,28)">
					        	  				   <?= $remaining ?>       
					        	  </div>
					        	  <?php }?>
					        	  <button class='addTk' value="<?= $row['unique_id'] ?>" style='margin-right:5px;outline:none;background:none'>
					        	    <span class="material-icons text-info">
add
</span>
					        	  </button>
				          </td>
								           <td class="quantity">
					        	<div class="input-group checkbox-wrap text-primary">
				             	<?= $row['tk'] ?>
				          	</div>
				          </td>          

				          
				           <td class="quantity">
					        	<div class="input-group checkbox-wrap text-primary">
					        	  <a href="border.php?id=<?= $row['unique_id']?>">visit</a>
					        	  </div>
				          </td>
				          

						    </tr>
		      <?php }} ?>

						  </tbody>
						</table>
									
	<a href='print.html' style='background:red;width:250px;height:100px' id="">Print</a>
					</div>
				</div>
			</div>
		</div>
	</section>



	<?php include 'include/addtk.php'; ?>






<script>
//const tags = document.getElementsByClassName('tag');
document.querySelector('#add_meal').addEventListener('click',()=>{
  

var person = document.getElementsByClassName('person');
  let id,breakfast,launch,dinner,meal;
  let today_meal='';
  let daily_meal='';
  for(let i=0;i<person.length;i++){
    meal=0;
    id=document.getElementById(person[i].id);
    
    breakfast = id.querySelector('.breakfast');
   launch = id.querySelector('.launch');
    dinner = id.querySelector('.dinner');
    guest = id.querySelector('.guest').value;
    if(breakfast.checked){
      meal+=0.5;
      breakfast='1';
    }
    else{
      breakfast='0';
    }
    if(launch.checked){
      meal+=1;
      launch='1';
    }
    else{
      launch='0';
    }
    if(dinner.checked){
      meal+=1;
      dinner='1';
    }
    else{
      dinner='0';
    }
    meal+=parseInt(guest);
    today_meal += `${person[i].id}:${meal};`;

    daily_meal +=`${person[i].id}:b=${breakfast},l=${launch},d=${dinner},g=${guest};`;
    
    
   }
  var fd = new FormData();
  fd.append('operation','add_meal');
  fd.append('daily_meal',daily_meal);
  fd.append('today_meal',today_meal);
 // alert(today_meal);
  //alert(daily_meal)
  $.ajax({
            url:"ajax/code.php",
              type: 'post',
              data: fd,
              contentType: false,
              processData: false,
              success: function(response){
               alert(response)
                ///location.reload();
              }
          });
  
})
</script>
  
 
<script>
    // Add an event listener to the print button
    document.getElementById('printButton').addEventListener('click', function() {
      // Manipulate the webpage to hide elements except the target div
    //  document.body.style.display = 'none'; // Hide the whole body
      document.querySelector('.table-wrap').style.display = 'block'; // Show the target div

      // Open the print dialog
      window.print();

      // Restore the webpage after printing
      document.body.style.display = 'block';
    });
  </script>


<?php include 'include/footer.php'; ?>
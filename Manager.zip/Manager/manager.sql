-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 19, 2023 at 12:24 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `manager`
--

-- --------------------------------------------------------

--
-- Table structure for table `border`
--

CREATE TABLE `border` (
  `id` int(11) NOT NULL,
  `unique_id` varchar(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `room` varchar(20) NOT NULL,
  `tk` int(11) NOT NULL,
  `total_meal` float NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `border`
--

INSERT INTO `border` (`id`, `unique_id`, `name`, `mobile`, `room`, `tk`, `total_meal`, `created_at`) VALUES
(40, 'z1rfMqLv', 'Rasel', '01518991660', '107', 1200, 27.5, '2023-07-02 15:28:43'),
(39, 'e4ZSfi8w', 'Hridoy Kormokar', '01865557883', '108', 1000, 26.5, '2023-07-02 15:28:12'),
(38, '30wDyQEy', 'Abu Bokkor', '01580408691', '110T', 1200, 26.5, '2023-07-02 15:27:31'),
(37, '9LQ9eUwn', 'Mohibul', '01902834667', '111T', 1400, 23, '2023-07-02 15:25:46'),
(36, 'TLIHdCwN', 'Ferdous', '01705890221', '106', 1500, 39.5, '2023-07-02 15:25:01'),
(35, 'um1tyNgm', 'Ajim', '01712041659', '105', 1100, 26, '2023-07-02 15:24:25'),
(34, 'mOBSdhma', 'Ruhul', '01701764366', '104', 1000, 24.5, '2023-07-02 15:23:49'),
(33, 'XD5j5VeO', 'Akram', '01775854520', '103', 1000, 26.5, '2023-07-02 15:23:22'),
(32, 'ZehRzCbH', 'Mobarok', '01991496112', '202', 1000, 25.5, '2023-07-02 15:22:37'),
(31, 'c9CWHNuQ', 'Miraj', '01782762354', '203', 1000, 26.5, '2023-07-02 15:22:00'),
(30, 'xcHVP0Dm', 'Bhasir', '01878760230', '203', 1000, 25.5, '2023-07-02 15:07:07'),
(41, 'fvWnO7Hn', 'Mehedi', '01704526243', '201', 1000, 24, '2023-07-02 15:29:14'),
(42, 'OAO70lxY', 'Mahafuj', '01856221186', '109', 1000, 26.5, '2023-07-02 15:49:35'),
(43, 'pjymIFv3', 'Tamim', ' 01798442425', '112T', 500, 22.5, '2023-07-03 05:15:03'),
(44, 'VU4Uq7YJ', 'Miraj', '01609956596', '103', 1200, 26.5, '2023-07-03 15:32:43'),
(45, 'NE6KrKRJ', 'Nobab', '01752127672', '104', 1000, 27.5, '2023-07-03 15:33:10'),
(46, 'h8ZtNpzt', 'Ovi', '01771635621', '105', 600, 14, '2023-07-03 15:33:37'),
(47, 'Sg9Baf4S', 'Monju', '01949467578', '112T', 1000, 26.5, '2023-07-03 15:34:02'),
(48, 'VzfhksjI', 'Kawsar', '##', '109', 1000, 26.5, '2023-07-03 15:34:55'),
(49, 'IjUAFW8z', 'Sharif', '###', '106', 1000, 26.5, '2023-07-03 15:36:10'),
(50, 'TeglWfYx', 'Ferdous', '01642121092', '109', 1100, 31, '2023-07-03 15:39:38'),
(51, 'ywUh7B4R', 'Mohatamim', '01518749114', '110', 1000, 26.5, '2023-07-03 15:40:03'),
(52, 'poYY4yzN', 'Abir', '##1', '113T', 1000, 25.5, '2023-07-04 14:51:08'),
(53, 'MzNIKRh4', 'Hasib', '##2', '102A', 1000, 24, '2023-07-04 14:52:22'),
(54, 'CxLjzxUU', 'Jihad', '##3', '111', 1000, 23.5, '2023-07-04 14:53:07'),
(55, 'MIribe3l', 'Rashedul', '##4', '111T', 1000, 24, '2023-07-04 14:53:34'),
(56, '8f67YQ0V', 'Hridoy Hossain', '###5', '114T', 800, 26, '2023-07-04 14:54:09'),
(57, 'BCMa1Yb1', 'Asraful', '####5', '110T', 1000, 4.5, '2023-07-05 11:25:09'),
(58, 'C6THBEoX', 'ASIF IQBAL', '01750076136', '110', 1000, 20.5, '2023-07-06 09:04:50'),
(59, '3gVZtbqq', 'Sadnan', '###525', '111', 700, 20.5, '2023-07-06 14:26:13'),
(60, 'MhlGpflU', 'Limon', '###6362', '108', 1000, 19.5, '2023-07-06 14:32:32'),
(61, 'EELncfZT', 'Monirul', '###07', '108', 1000, 15, '2023-07-07 12:18:09'),
(63, 'eWlWS2j7', 'Johurul ', '######6', '112T', 500, 12.5, '2023-07-09 13:46:53'),
(64, 'sp2Efgni', 'Ikhlas', '####90', '203', 400, 11, '2023-07-09 13:47:18'),
(65, 'kvJhGvvu', 'Nahid', '##63663636', '114', 500, 11.5, '2023-07-09 13:55:04'),
(66, 'g1TWRfv8', 'Sobuj', '###66#6', '107', 400, 6, '2023-07-10 10:24:25'),
(67, 'bHAPNtBC', 'Fahad', '####67', '102A', 400, 11, '2023-07-10 10:53:51');

-- --------------------------------------------------------

--
-- Table structure for table `extra`
--

CREATE TABLE `extra` (
  `id` int(11) NOT NULL,
  `description` text NOT NULL,
  `tk` mediumint(9) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `extra`
--

INSERT INTO `extra` (`id`, `description`, `tk`, `created_at`) VALUES
(3, 'জিরা ১০০গ্রাম', 100, '2023-07-02 18:00:00'),
(4, 'পেয়াজ ১কেজি', 45, '2023-07-04 18:00:00'),
(5, 'মসলা ', 685, '2023-07-06 18:00:00'),
(6, 'সরিষার তেল', 120, '2023-07-03 18:00:00'),
(7, 'মিল বিড়াল নষ্ট করছে,আবির(১১৩T)', 60, '2023-07-05 18:00:00'),
(8, 'মিল বিড়াল নষ্ট করছে, আজিম(১০৫)', 50, '2023-07-03 18:00:00'),
(9, 'সয়াবিন তেল ১ লিটার', 160, '2023-07-10 18:00:00'),
(10, 'মিল হারাইছে দুপুরে - আজিম(১০৫)', 50, '2023-07-11 18:00:00'),
(11, 'শসা ২কেজি,লেবু ১০পিস', 100, '2023-07-12 18:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `meal`
--

CREATE TABLE `meal` (
  `id` int(11) NOT NULL,
  `today_meal` text NOT NULL,
  `daily_meal` text NOT NULL,
  `created_at` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `meal`
--

INSERT INTO `meal` (`id`, `today_meal`, `daily_meal`, `created_at`) VALUES
(11, 'xcHVP0Dm:1;c9CWHNuQ:1;ZehRzCbH:1;XD5j5VeO:1;mOBSdhma:1;um1tyNgm:1;TLIHdCwN:2;9LQ9eUwn:0;30wDyQEy:1;e4ZSfi8w:1;z1rfMqLv:1;fvWnO7Hn:1;OAO70lxY:1;pjymIFv3:0;VU4Uq7YJ:1;NE6KrKRJ:1;h8ZtNpzt:1;Sg9Baf4S:1;VzfhksjI:1;IjUAFW8z:1;TeglWfYx:1;ywUh7B4R:1;', 'xcHVP0Dm:b=0,l=0,d=1,g=0;c9CWHNuQ:b=0,l=0,d=1,g=0;ZehRzCbH:b=0,l=0,d=1,g=0;XD5j5VeO:b=0,l=0,d=1,g=0;mOBSdhma:b=0,l=0,d=1,g=0;um1tyNgm:b=0,l=0,d=1,g=0;TLIHdCwN:b=0,l=0,d=1,g=1;9LQ9eUwn:b=0,l=0,d=0,g=0;30wDyQEy:b=0,l=0,d=1,g=0;e4ZSfi8w:b=0,l=0,d=1,g=0;z1rfMqLv:b=0,l=0,d=1,g=0;fvWnO7Hn:b=0,l=0,d=1,g=0;OAO70lxY:b=0,l=0,d=1,g=0;pjymIFv3:b=0,l=0,d=0,g=0;VU4Uq7YJ:b=0,l=0,d=1,g=0;NE6KrKRJ:b=0,l=0,d=1,g=0;h8ZtNpzt:b=0,l=0,d=1,g=0;Sg9Baf4S:b=0,l=0,d=1,g=0;VzfhksjI:b=0,l=0,d=1,g=0;IjUAFW8z:b=0,l=0,d=1,g=0;TeglWfYx:b=0,l=0,d=1,g=0;ywUh7B4R:b=0,l=0,d=1,g=0;', '2023-07-03'),
(12, 'xcHVP0Dm:2.5;c9CWHNuQ:2.5;ZehRzCbH:2.5;XD5j5VeO:2.5;mOBSdhma:2.5;um1tyNgm:2.5;TLIHdCwN:4.5;9LQ9eUwn:1;30wDyQEy:2.5;e4ZSfi8w:2.5;z1rfMqLv:2.5;fvWnO7Hn:2.5;OAO70lxY:2.5;pjymIFv3:0;VU4Uq7YJ:2.5;NE6KrKRJ:2.5;h8ZtNpzt:0.5;Sg9Baf4S:2.5;VzfhksjI:2.5;IjUAFW8z:2.5;TeglWfYx:2.5;ywUh7B4R:2.5;poYY4yzN:2.5;MzNIKRh4:1;CxLjzxUU:2;MIribe3l:1;8f67YQ0V:1;', 'xcHVP0Dm:b=1,l=1,d=1,g=0;c9CWHNuQ:b=1,l=1,d=1,g=0;ZehRzCbH:b=1,l=1,d=1,g=0;XD5j5VeO:b=1,l=1,d=1,g=0;mOBSdhma:b=1,l=1,d=1,g=0;um1tyNgm:b=1,l=1,d=1,g=0;TLIHdCwN:b=1,l=1,d=1,g=2.5;9LQ9eUwn:b=0,l=0,d=1,g=0;30wDyQEy:b=1,l=1,d=1,g=0;e4ZSfi8w:b=1,l=1,d=1,g=0;z1rfMqLv:b=1,l=1,d=1,g=0;fvWnO7Hn:b=1,l=1,d=1,g=0;OAO70lxY:b=1,l=1,d=1,g=0;pjymIFv3:b=0,l=0,d=0,g=0;VU4Uq7YJ:b=1,l=1,d=1,g=0;NE6KrKRJ:b=1,l=1,d=1,g=0;h8ZtNpzt:b=1,l=0,d=0,g=0;Sg9Baf4S:b=1,l=1,d=1,g=0;VzfhksjI:b=1,l=1,d=1,g=0;IjUAFW8z:b=1,l=1,d=1,g=0;TeglWfYx:b=1,l=1,d=1,g=0;ywUh7B4R:b=1,l=1,d=1,g=0;poYY4yzN:b=1,l=1,d=1,g=0;MzNIKRh4:b=0,l=0,d=1,g=0;CxLjzxUU:b=0,l=1,d=1,g=0;MIribe3l:b=0,l=0,d=1,g=0;8f67YQ0V:b=0,l=0,d=1,g=0;', '2023-07-04'),
(13, 'xcHVP0Dm:2.5;c9CWHNuQ:2.5;ZehRzCbH:2.5;XD5j5VeO:2.5;mOBSdhma:1.5;um1tyNgm:2.5;TLIHdCwN:7.5;9LQ9eUwn:2.5;30wDyQEy:2.5;e4ZSfi8w:2.5;z1rfMqLv:2.5;fvWnO7Hn:2.5;OAO70lxY:2.5;pjymIFv3:2.5;VU4Uq7YJ:2.5;NE6KrKRJ:2.5;h8ZtNpzt:0.5;Sg9Baf4S:2.5;VzfhksjI:2.5;IjUAFW8z:2.5;TeglWfYx:2.5;ywUh7B4R:2.5;poYY4yzN:2.5;MzNIKRh4:2.5;CxLjzxUU:2;MIribe3l:2.5;8f67YQ0V:2.5;BCMa1Yb1:1;', 'xcHVP0Dm:b=1,l=1,d=1,g=0;c9CWHNuQ:b=1,l=1,d=1,g=0;ZehRzCbH:b=1,l=1,d=1,g=0;XD5j5VeO:b=1,l=1,d=1,g=0;mOBSdhma:b=1,l=1,d=0,g=0;um1tyNgm:b=1,l=1,d=1,g=0;TLIHdCwN:b=1,l=1,d=1,g=5;9LQ9eUwn:b=1,l=1,d=1,g=0;30wDyQEy:b=1,l=1,d=1,g=0;e4ZSfi8w:b=1,l=1,d=1,g=0;z1rfMqLv:b=1,l=1,d=1,g=0;fvWnO7Hn:b=1,l=1,d=1,g=0;OAO70lxY:b=1,l=1,d=1,g=0;pjymIFv3:b=1,l=1,d=1,g=0;VU4Uq7YJ:b=1,l=1,d=1,g=0;NE6KrKRJ:b=1,l=1,d=1,g=0;h8ZtNpzt:b=1,l=0,d=0,g=0;Sg9Baf4S:b=1,l=1,d=1,g=0;VzfhksjI:b=1,l=1,d=1,g=0;IjUAFW8z:b=1,l=1,d=1,g=0;TeglWfYx:b=1,l=1,d=1,g=0;ywUh7B4R:b=1,l=1,d=1,g=0;poYY4yzN:b=1,l=1,d=1,g=0;MzNIKRh4:b=1,l=1,d=1,g=0;CxLjzxUU:b=0,l=1,d=1,g=0;MIribe3l:b=1,l=1,d=1,g=0;8f67YQ0V:b=1,l=1,d=1,g=0;BCMa1Yb1:b=0,l=0,d=1,g=0;', '2023-07-05'),
(14, 'xcHVP0Dm:2;c9CWHNuQ:2;ZehRzCbH:2;XD5j5VeO:2;mOBSdhma:3;um1tyNgm:2;TLIHdCwN:4;9LQ9eUwn:2;30wDyQEy:2;e4ZSfi8w:2;z1rfMqLv:2;fvWnO7Hn:2;OAO70lxY:2;pjymIFv3:2;VU4Uq7YJ:2;NE6KrKRJ:2;h8ZtNpzt:1;Sg9Baf4S:2;VzfhksjI:2;IjUAFW8z:2;TeglWfYx:3;ywUh7B4R:2;poYY4yzN:2;MzNIKRh4:2;CxLjzxUU:2;MIribe3l:2;8f67YQ0V:3;BCMa1Yb1:0;C6THBEoX:2;3gVZtbqq:2;MhlGpflU:2;', 'xcHVP0Dm:b=0,l=1,d=1,g=0;c9CWHNuQ:b=0,l=1,d=1,g=0;ZehRzCbH:b=0,l=1,d=1,g=0;XD5j5VeO:b=0,l=1,d=1,g=0;mOBSdhma:b=0,l=1,d=1,g=1;um1tyNgm:b=0,l=1,d=1,g=0;TLIHdCwN:b=0,l=1,d=1,g=2;9LQ9eUwn:b=0,l=1,d=1,g=0;30wDyQEy:b=0,l=1,d=1,g=0;e4ZSfi8w:b=0,l=1,d=1,g=0;z1rfMqLv:b=0,l=1,d=1,g=0;fvWnO7Hn:b=0,l=1,d=1,g=0;OAO70lxY:b=0,l=1,d=1,g=0;pjymIFv3:b=0,l=1,d=1,g=0;VU4Uq7YJ:b=0,l=1,d=1,g=0;NE6KrKRJ:b=0,l=1,d=1,g=0;h8ZtNpzt:b=0,l=1,d=0,g=0;Sg9Baf4S:b=0,l=1,d=1,g=0;VzfhksjI:b=0,l=1,d=1,g=0;IjUAFW8z:b=0,l=1,d=1,g=0;TeglWfYx:b=0,l=1,d=1,g=1;ywUh7B4R:b=0,l=1,d=1,g=0;poYY4yzN:b=0,l=1,d=1,g=0;MzNIKRh4:b=0,l=1,d=1,g=0;CxLjzxUU:b=0,l=1,d=1,g=0;MIribe3l:b=0,l=1,d=1,g=0;8f67YQ0V:b=0,l=1,d=1,g=1;BCMa1Yb1:b=0,l=0,d=0,g=0;C6THBEoX:b=0,l=1,d=1,g=0;3gVZtbqq:b=0,l=1,d=1,g=0;MhlGpflU:b=0,l=1,d=1,g=0;', '2023-07-06'),
(15, 'xcHVP0Dm:2.5;c9CWHNuQ:2.5;ZehRzCbH:2.5;XD5j5VeO:2.5;mOBSdhma:2.5;um1tyNgm:2.5;TLIHdCwN:3.5;9LQ9eUwn:2.5;30wDyQEy:2.5;e4ZSfi8w:2.5;z1rfMqLv:2.5;fvWnO7Hn:2.5;OAO70lxY:2.5;pjymIFv3:2.5;VU4Uq7YJ:2.5;NE6KrKRJ:2.5;h8ZtNpzt:1.5;Sg9Baf4S:2.5;VzfhksjI:2.5;IjUAFW8z:2.5;TeglWfYx:3.5;ywUh7B4R:2.5;poYY4yzN:2.5;MzNIKRh4:2.5;CxLjzxUU:2.5;MIribe3l:2.5;8f67YQ0V:2.5;BCMa1Yb1:0;C6THBEoX:2.5;3gVZtbqq:2.5;MhlGpflU:2.5;EELncfZT:1;', 'xcHVP0Dm:b=1,l=1,d=1,g=0;c9CWHNuQ:b=1,l=1,d=1,g=0;ZehRzCbH:b=1,l=1,d=1,g=0;XD5j5VeO:b=1,l=1,d=1,g=0;mOBSdhma:b=1,l=1,d=1,g=0;um1tyNgm:b=1,l=1,d=1,g=0;TLIHdCwN:b=1,l=1,d=1,g=1;9LQ9eUwn:b=1,l=1,d=1,g=0;30wDyQEy:b=1,l=1,d=1,g=0;e4ZSfi8w:b=1,l=1,d=1,g=0;z1rfMqLv:b=1,l=1,d=1,g=0;fvWnO7Hn:b=1,l=1,d=1,g=0;OAO70lxY:b=1,l=1,d=1,g=0;pjymIFv3:b=1,l=1,d=1,g=0;VU4Uq7YJ:b=1,l=1,d=1,g=0;NE6KrKRJ:b=1,l=1,d=1,g=0;h8ZtNpzt:b=1,l=1,d=0,g=0;Sg9Baf4S:b=1,l=1,d=1,g=0;VzfhksjI:b=1,l=1,d=1,g=0;IjUAFW8z:b=1,l=1,d=1,g=0;TeglWfYx:b=1,l=1,d=1,g=1;ywUh7B4R:b=1,l=1,d=1,g=0;poYY4yzN:b=1,l=1,d=1,g=0;MzNIKRh4:b=1,l=1,d=1,g=0;CxLjzxUU:b=1,l=1,d=1,g=0;MIribe3l:b=1,l=1,d=1,g=0;8f67YQ0V:b=1,l=1,d=0,g=1;BCMa1Yb1:b=0,l=0,d=0,g=0;C6THBEoX:b=1,l=1,d=1,g=0;3gVZtbqq:b=1,l=1,d=1,g=0;MhlGpflU:b=1,l=1,d=1,g=0;EELncfZT:b=0,l=0,d=1,g=0;', '2023-07-07'),
(16, 'xcHVP0Dm:2.5;c9CWHNuQ:2.5;ZehRzCbH:2.5;XD5j5VeO:2.5;mOBSdhma:2.5;um1tyNgm:2.5;TLIHdCwN:4.5;9LQ9eUwn:2.5;30wDyQEy:2.5;e4ZSfi8w:2.5;z1rfMqLv:2.5;fvWnO7Hn:2.5;OAO70lxY:2.5;pjymIFv3:1.5;VU4Uq7YJ:2.5;NE6KrKRJ:2.5;h8ZtNpzt:1.5;Sg9Baf4S:2.5;VzfhksjI:2.5;IjUAFW8z:2.5;TeglWfYx:2.5;ywUh7B4R:2.5;poYY4yzN:2.5;MzNIKRh4:2.5;CxLjzxUU:2.5;MIribe3l:2.5;8f67YQ0V:3.5;BCMa1Yb1:0;C6THBEoX:2.5;3gVZtbqq:2.5;MhlGpflU:2.5;EELncfZT:2;', 'xcHVP0Dm:b=1,l=1,d=1,g=0;c9CWHNuQ:b=1,l=1,d=1,g=0;ZehRzCbH:b=1,l=1,d=1,g=0;XD5j5VeO:b=1,l=1,d=1,g=0;mOBSdhma:b=1,l=1,d=1,g=0;um1tyNgm:b=1,l=1,d=1,g=0;TLIHdCwN:b=1,l=1,d=1,g=2;9LQ9eUwn:b=1,l=1,d=1,g=0;30wDyQEy:b=1,l=1,d=1,g=0;e4ZSfi8w:b=1,l=1,d=1,g=0;z1rfMqLv:b=1,l=1,d=1,g=0;fvWnO7Hn:b=1,l=1,d=1,g=0;OAO70lxY:b=1,l=1,d=1,g=0;pjymIFv3:b=1,l=0,d=1,g=0;VU4Uq7YJ:b=1,l=1,d=1,g=0;NE6KrKRJ:b=1,l=1,d=1,g=0;h8ZtNpzt:b=1,l=1,d=0,g=0;Sg9Baf4S:b=1,l=1,d=1,g=0;VzfhksjI:b=1,l=1,d=1,g=0;IjUAFW8z:b=1,l=1,d=1,g=0;TeglWfYx:b=1,l=1,d=1,g=0;ywUh7B4R:b=1,l=1,d=1,g=0;poYY4yzN:b=1,l=1,d=1,g=0;MzNIKRh4:b=1,l=1,d=1,g=0;CxLjzxUU:b=1,l=1,d=1,g=0;MIribe3l:b=1,l=1,d=1,g=0;8f67YQ0V:b=1,l=1,d=1,g=1;BCMa1Yb1:b=0,l=0,d=0,g=0;C6THBEoX:b=1,l=1,d=1,g=0;3gVZtbqq:b=1,l=1,d=1,g=0;MhlGpflU:b=1,l=1,d=1,g=0;EELncfZT:b=0,l=1,d=1,g=0;', '2023-07-08'),
(17, 'xcHVP0Dm:2.5;c9CWHNuQ:2.5;ZehRzCbH:2.5;XD5j5VeO:2.5;mOBSdhma:2.5;um1tyNgm:2.5;TLIHdCwN:2.5;9LQ9eUwn:2.5;30wDyQEy:2.5;e4ZSfi8w:2.5;z1rfMqLv:3.5;fvWnO7Hn:2.5;OAO70lxY:2.5;pjymIFv3:3;VU4Uq7YJ:2.5;NE6KrKRJ:2.5;h8ZtNpzt:1.5;Sg9Baf4S:2.5;VzfhksjI:2.5;IjUAFW8z:2.5;TeglWfYx:2.5;ywUh7B4R:2.5;poYY4yzN:2.5;MzNIKRh4:2.5;CxLjzxUU:2.5;MIribe3l:2.5;8f67YQ0V:2.5;BCMa1Yb1:0;C6THBEoX:2.5;3gVZtbqq:2.5;MhlGpflU:2.5;EELncfZT:2;eWlWS2j7:2;sp2Efgni:1;kvJhGvvu:2;', 'xcHVP0Dm:b=1,l=1,d=1,g=0;c9CWHNuQ:b=1,l=1,d=1,g=0;ZehRzCbH:b=1,l=1,d=1,g=0;XD5j5VeO:b=1,l=1,d=1,g=0;mOBSdhma:b=1,l=1,d=1,g=0;um1tyNgm:b=1,l=1,d=1,g=0;TLIHdCwN:b=1,l=1,d=1,g=0;9LQ9eUwn:b=1,l=1,d=1,g=0;30wDyQEy:b=1,l=1,d=1,g=0;e4ZSfi8w:b=1,l=1,d=1,g=0;z1rfMqLv:b=1,l=1,d=1,g=1;fvWnO7Hn:b=1,l=1,d=1,g=0;OAO70lxY:b=1,l=1,d=1,g=0;pjymIFv3:b=1,l=1,d=1,g=0.5;VU4Uq7YJ:b=1,l=1,d=1,g=0;NE6KrKRJ:b=1,l=1,d=1,g=0;h8ZtNpzt:b=1,l=1,d=0,g=0;Sg9Baf4S:b=1,l=1,d=1,g=0;VzfhksjI:b=1,l=1,d=1,g=0;IjUAFW8z:b=1,l=1,d=1,g=0;TeglWfYx:b=1,l=1,d=1,g=0;ywUh7B4R:b=1,l=1,d=1,g=0;poYY4yzN:b=1,l=1,d=1,g=0;MzNIKRh4:b=1,l=1,d=1,g=0;CxLjzxUU:b=1,l=1,d=1,g=0;MIribe3l:b=1,l=1,d=1,g=0;8f67YQ0V:b=1,l=1,d=1,g=0;BCMa1Yb1:b=0,l=0,d=0,g=0;C6THBEoX:b=1,l=1,d=1,g=0;3gVZtbqq:b=1,l=1,d=1,g=0;MhlGpflU:b=1,l=1,d=1,g=0;EELncfZT:b=0,l=1,d=1,g=0;eWlWS2j7:b=0,l=1,d=1,g=0;sp2Efgni:b=0,l=0,d=1,g=0;kvJhGvvu:b=0,l=1,d=1,g=0;', '2023-07-09'),
(18, 'xcHVP0Dm:1;c9CWHNuQ:2;ZehRzCbH:1;XD5j5VeO:2;mOBSdhma:0;um1tyNgm:2;TLIHdCwN:2;9LQ9eUwn:2;30wDyQEy:2;e4ZSfi8w:2;z1rfMqLv:2;fvWnO7Hn:1;OAO70lxY:2;pjymIFv3:2;VU4Uq7YJ:2;NE6KrKRJ:2;h8ZtNpzt:1;Sg9Baf4S:2;VzfhksjI:2;IjUAFW8z:2;TeglWfYx:2;ywUh7B4R:2;poYY4yzN:2;MzNIKRh4:2;CxLjzxUU:2;MIribe3l:2;8f67YQ0V:2;BCMa1Yb1:0;C6THBEoX:2;3gVZtbqq:2;MhlGpflU:2;EELncfZT:2;eWlWS2j7:2;sp2Efgni:1;kvJhGvvu:2;g1TWRfv8:2;bHAPNtBC:2;', 'xcHVP0Dm:b=0,l=0,d=1,g=0;c9CWHNuQ:b=0,l=0,d=1,g=1;ZehRzCbH:b=0,l=0,d=1,g=0;XD5j5VeO:b=0,l=1,d=1,g=0;mOBSdhma:b=0,l=0,d=0,g=0;um1tyNgm:b=0,l=1,d=1,g=0;TLIHdCwN:b=0,l=1,d=1,g=0;9LQ9eUwn:b=0,l=1,d=1,g=0;30wDyQEy:b=0,l=1,d=1,g=0;e4ZSfi8w:b=0,l=1,d=1,g=0;z1rfMqLv:b=0,l=1,d=1,g=0;fvWnO7Hn:b=0,l=0,d=1,g=0;OAO70lxY:b=0,l=1,d=1,g=0;pjymIFv3:b=0,l=1,d=1,g=0;VU4Uq7YJ:b=0,l=1,d=1,g=0;NE6KrKRJ:b=0,l=1,d=1,g=0;h8ZtNpzt:b=0,l=1,d=0,g=0;Sg9Baf4S:b=0,l=1,d=1,g=0;VzfhksjI:b=0,l=1,d=1,g=0;IjUAFW8z:b=0,l=1,d=1,g=0;TeglWfYx:b=0,l=1,d=1,g=0;ywUh7B4R:b=0,l=1,d=1,g=0;poYY4yzN:b=0,l=1,d=1,g=0;MzNIKRh4:b=0,l=1,d=1,g=0;CxLjzxUU:b=0,l=1,d=1,g=0;MIribe3l:b=0,l=1,d=1,g=0;8f67YQ0V:b=0,l=1,d=1,g=0;BCMa1Yb1:b=0,l=0,d=0,g=0;C6THBEoX:b=0,l=1,d=1,g=0;3gVZtbqq:b=0,l=1,d=1,g=0;MhlGpflU:b=0,l=1,d=1,g=0;EELncfZT:b=0,l=1,d=1,g=0;eWlWS2j7:b=0,l=1,d=1,g=0;sp2Efgni:b=0,l=0,d=1,g=0;kvJhGvvu:b=0,l=1,d=1,g=0;g1TWRfv8:b=0,l=1,d=1,g=0;bHAPNtBC:b=0,l=1,d=1,g=0;', '2023-07-10'),
(19, 'xcHVP0Dm:2.5;c9CWHNuQ:2.5;ZehRzCbH:2.5;XD5j5VeO:2.5;mOBSdhma:2.5;um1tyNgm:2.5;TLIHdCwN:2.5;9LQ9eUwn:1.5;30wDyQEy:2.5;e4ZSfi8w:2.5;z1rfMqLv:2.5;fvWnO7Hn:2.5;OAO70lxY:2.5;pjymIFv3:2.5;VU4Uq7YJ:2.5;NE6KrKRJ:2.5;h8ZtNpzt:1.5;Sg9Baf4S:2.5;VzfhksjI:2.5;IjUAFW8z:2.5;TeglWfYx:2.5;ywUh7B4R:2.5;poYY4yzN:2.5;MzNIKRh4:2.5;CxLjzxUU:2.5;MIribe3l:2.5;8f67YQ0V:2.5;BCMa1Yb1:0;C6THBEoX:2.5;3gVZtbqq:2.5;MhlGpflU:1.5;EELncfZT:1.5;eWlWS2j7:2;sp2Efgni:2.5;kvJhGvvu:2;g1TWRfv8:2.5;bHAPNtBC:2.5;', 'xcHVP0Dm:b=1,l=1,d=1,g=0;c9CWHNuQ:b=1,l=1,d=1,g=0;ZehRzCbH:b=1,l=1,d=1,g=0;XD5j5VeO:b=1,l=1,d=1,g=0;mOBSdhma:b=1,l=1,d=1,g=0;um1tyNgm:b=1,l=1,d=1,g=0;TLIHdCwN:b=1,l=1,d=1,g=0;9LQ9eUwn:b=1,l=0,d=1,g=0;30wDyQEy:b=1,l=1,d=1,g=0;e4ZSfi8w:b=1,l=1,d=1,g=0;z1rfMqLv:b=1,l=1,d=1,g=0;fvWnO7Hn:b=1,l=1,d=1,g=0;OAO70lxY:b=1,l=1,d=1,g=0;pjymIFv3:b=1,l=1,d=1,g=0;VU4Uq7YJ:b=1,l=1,d=1,g=0;NE6KrKRJ:b=1,l=1,d=1,g=0;h8ZtNpzt:b=1,l=1,d=0,g=0;Sg9Baf4S:b=1,l=1,d=1,g=0;VzfhksjI:b=1,l=1,d=1,g=0;IjUAFW8z:b=1,l=1,d=1,g=0;TeglWfYx:b=1,l=1,d=1,g=0;ywUh7B4R:b=1,l=1,d=1,g=0;poYY4yzN:b=1,l=1,d=1,g=0;MzNIKRh4:b=1,l=1,d=1,g=0;CxLjzxUU:b=1,l=1,d=1,g=0;MIribe3l:b=1,l=1,d=1,g=0;8f67YQ0V:b=1,l=1,d=1,g=0;BCMa1Yb1:b=0,l=0,d=0,g=0;C6THBEoX:b=1,l=1,d=1,g=0;3gVZtbqq:b=1,l=1,d=1,g=0;MhlGpflU:b=1,l=1,d=0,g=0;EELncfZT:b=1,l=1,d=0,g=0;eWlWS2j7:b=0,l=1,d=1,g=0;sp2Efgni:b=1,l=1,d=1,g=0;kvJhGvvu:b=0,l=1,d=1,g=0;g1TWRfv8:b=1,l=1,d=1,g=0;bHAPNtBC:b=1,l=1,d=1,g=0;', '2023-07-11'),
(20, 'xcHVP0Dm:2.5;c9CWHNuQ:2.5;ZehRzCbH:2.5;XD5j5VeO:2.5;mOBSdhma:2.5;um1tyNgm:2;TLIHdCwN:2.5;9LQ9eUwn:2.5;30wDyQEy:2.5;e4ZSfi8w:2.5;z1rfMqLv:2.5;fvWnO7Hn:2.5;OAO70lxY:2.5;pjymIFv3:2.5;VU4Uq7YJ:2.5;NE6KrKRJ:3.5;h8ZtNpzt:1;Sg9Baf4S:2.5;VzfhksjI:2.5;IjUAFW8z:2.5;TeglWfYx:2.5;ywUh7B4R:2.5;poYY4yzN:2.5;MzNIKRh4:2.5;CxLjzxUU:2.5;MIribe3l:2.5;8f67YQ0V:2.5;BCMa1Yb1:0;C6THBEoX:2.5;3gVZtbqq:2.5;MhlGpflU:2.5;EELncfZT:2.5;eWlWS2j7:2.5;sp2Efgni:2.5;kvJhGvvu:1.5;g1TWRfv8:1.5;bHAPNtBC:2.5;', 'xcHVP0Dm:b=1,l=1,d=1,g=0;c9CWHNuQ:b=1,l=1,d=1,g=0;ZehRzCbH:b=1,l=1,d=1,g=0;XD5j5VeO:b=1,l=1,d=1,g=0;mOBSdhma:b=1,l=1,d=1,g=0;um1tyNgm:b=0,l=1,d=1,g=0;TLIHdCwN:b=1,l=1,d=1,g=0;9LQ9eUwn:b=1,l=1,d=1,g=0;30wDyQEy:b=1,l=1,d=1,g=0;e4ZSfi8w:b=1,l=1,d=1,g=0;z1rfMqLv:b=1,l=1,d=1,g=0;fvWnO7Hn:b=1,l=1,d=1,g=0;OAO70lxY:b=1,l=1,d=1,g=0;pjymIFv3:b=1,l=1,d=1,g=0;VU4Uq7YJ:b=1,l=1,d=1,g=0;NE6KrKRJ:b=1,l=1,d=1,g=1;h8ZtNpzt:b=0,l=1,d=0,g=0;Sg9Baf4S:b=1,l=1,d=1,g=0;VzfhksjI:b=1,l=1,d=1,g=0;IjUAFW8z:b=1,l=1,d=1,g=0;TeglWfYx:b=1,l=1,d=1,g=0;ywUh7B4R:b=1,l=1,d=1,g=0;poYY4yzN:b=1,l=1,d=1,g=0;MzNIKRh4:b=1,l=1,d=1,g=0;CxLjzxUU:b=1,l=1,d=1,g=0;MIribe3l:b=1,l=1,d=1,g=0;8f67YQ0V:b=1,l=1,d=1,g=0;BCMa1Yb1:b=0,l=0,d=0,g=0;C6THBEoX:b=1,l=1,d=1,g=0;3gVZtbqq:b=1,l=1,d=1,g=0;MhlGpflU:b=1,l=1,d=1,g=0;EELncfZT:b=1,l=1,d=1,g=0;eWlWS2j7:b=1,l=1,d=1,g=0;sp2Efgni:b=1,l=1,d=1,g=0;kvJhGvvu:b=1,l=1,d=0,g=0;g1TWRfv8:b=1,l=1,d=0,g=0;bHAPNtBC:b=1,l=1,d=1,g=0;', '2023-07-12'),
(21, 'bHAPNtBC:3.5;MzNIKRh4:3.5;XD5j5VeO:3.5;VU4Uq7YJ:3.5;mOBSdhma:3.5;NE6KrKRJ:3.5;um1tyNgm:3.5;h8ZtNpzt:2.5;TLIHdCwN:3.5;IjUAFW8z:3.5;z1rfMqLv:3.5;g1TWRfv8:0;e4ZSfi8w:3.5;EELncfZT:3.5;MhlGpflU:3.5;OAO70lxY:3.5;VzfhksjI:3.5;TeglWfYx:6;C6THBEoX:3.5;ywUh7B4R:3.5;30wDyQEy:3.5;BCMa1Yb1:3;CxLjzxUU:2.5;3gVZtbqq:3.5;MIribe3l:3.5;9LQ9eUwn:3.5;Sg9Baf4S:3.5;eWlWS2j7:3.5;pjymIFv3:3.5;poYY4yzN:3.5;kvJhGvvu:3.5;8f67YQ0V:3.5;fvWnO7Hn:2.5;ZehRzCbH:3.5;xcHVP0Dm:3.5;c9CWHNuQ:3.5;sp2Efgni:3.5;', 'bHAPNtBC:b=1,l=1,d=1,g=1;MzNIKRh4:b=1,l=1,d=1,g=1;XD5j5VeO:b=1,l=1,d=1,g=1;VU4Uq7YJ:b=1,l=1,d=1,g=1;mOBSdhma:b=1,l=1,d=1,g=1;NE6KrKRJ:b=1,l=1,d=1,g=1;um1tyNgm:b=1,l=1,d=1,g=1;h8ZtNpzt:b=1,l=1,d=0,g=1;TLIHdCwN:b=1,l=1,d=1,g=1;IjUAFW8z:b=1,l=1,d=1,g=1;z1rfMqLv:b=1,l=1,d=1,g=1;g1TWRfv8:b=0,l=0,d=0,g=0;e4ZSfi8w:b=1,l=1,d=1,g=1;EELncfZT:b=1,l=1,d=1,g=1;MhlGpflU:b=1,l=1,d=1,g=1;OAO70lxY:b=1,l=1,d=1,g=1;VzfhksjI:b=1,l=1,d=1,g=1;TeglWfYx:b=1,l=1,d=1,g=3.5;C6THBEoX:b=1,l=1,d=1,g=1;ywUh7B4R:b=1,l=1,d=1,g=1;30wDyQEy:b=1,l=1,d=1,g=1;BCMa1Yb1:b=0,l=1,d=1,g=1;CxLjzxUU:b=1,l=1,d=0,g=1;3gVZtbqq:b=1,l=1,d=1,g=1;MIribe3l:b=1,l=1,d=1,g=1;9LQ9eUwn:b=1,l=1,d=1,g=1;Sg9Baf4S:b=1,l=1,d=1,g=1;eWlWS2j7:b=1,l=1,d=1,g=1;pjymIFv3:b=1,l=1,d=1,g=1;poYY4yzN:b=1,l=1,d=1,g=1;kvJhGvvu:b=1,l=1,d=1,g=1;8f67YQ0V:b=1,l=1,d=1,g=1;fvWnO7Hn:b=1,l=1,d=0,g=1;ZehRzCbH:b=1,l=1,d=1,g=1;xcHVP0Dm:b=1,l=1,d=1,g=1;c9CWHNuQ:b=1,l=1,d=1,g=1;sp2Efgni:b=1,l=1,d=1,g=1;', '2023-07-13'),
(22, 'bHAPNtBC:0.5;MzNIKRh4:0.5;XD5j5VeO:0.5;VU4Uq7YJ:0.5;mOBSdhma:0.5;NE6KrKRJ:0.5;um1tyNgm:0.5;h8ZtNpzt:0.5;TLIHdCwN:0.5;IjUAFW8z:0.5;z1rfMqLv:0.5;g1TWRfv8:0;e4ZSfi8w:0.5;EELncfZT:0.5;MhlGpflU:0.5;OAO70lxY:0.5;VzfhksjI:0.5;TeglWfYx:0.5;C6THBEoX:0.5;ywUh7B4R:0.5;30wDyQEy:0.5;BCMa1Yb1:0.5;CxLjzxUU:0.5;3gVZtbqq:0.5;MIribe3l:0.5;9LQ9eUwn:0.5;Sg9Baf4S:0.5;eWlWS2j7:0.5;pjymIFv3:0.5;poYY4yzN:0.5;kvJhGvvu:0.5;8f67YQ0V:0.5;fvWnO7Hn:0;ZehRzCbH:0.5;xcHVP0Dm:0.5;c9CWHNuQ:0.5;sp2Efgni:0.5;', 'bHAPNtBC:b=1,l=0,d=0,g=0;MzNIKRh4:b=1,l=0,d=0,g=0;XD5j5VeO:b=1,l=0,d=0,g=0;VU4Uq7YJ:b=1,l=0,d=0,g=0;mOBSdhma:b=1,l=0,d=0,g=0;NE6KrKRJ:b=1,l=0,d=0,g=0;um1tyNgm:b=1,l=0,d=0,g=0;h8ZtNpzt:b=1,l=0,d=0,g=0;TLIHdCwN:b=1,l=0,d=0,g=0;IjUAFW8z:b=1,l=0,d=0,g=0;z1rfMqLv:b=1,l=0,d=0,g=0;g1TWRfv8:b=0,l=0,d=0,g=0;e4ZSfi8w:b=1,l=0,d=0,g=0;EELncfZT:b=1,l=0,d=0,g=0;MhlGpflU:b=1,l=0,d=0,g=0;OAO70lxY:b=1,l=0,d=0,g=0;VzfhksjI:b=1,l=0,d=0,g=0;TeglWfYx:b=1,l=0,d=0,g=0;C6THBEoX:b=1,l=0,d=0,g=0;ywUh7B4R:b=1,l=0,d=0,g=0;30wDyQEy:b=1,l=0,d=0,g=0;BCMa1Yb1:b=1,l=0,d=0,g=0;CxLjzxUU:b=1,l=0,d=0,g=0;3gVZtbqq:b=1,l=0,d=0,g=0;MIribe3l:b=1,l=0,d=0,g=0;9LQ9eUwn:b=1,l=0,d=0,g=0;Sg9Baf4S:b=1,l=0,d=0,g=0;eWlWS2j7:b=1,l=0,d=0,g=0;pjymIFv3:b=1,l=0,d=0,g=0;poYY4yzN:b=1,l=0,d=0,g=0;kvJhGvvu:b=1,l=0,d=0,g=0;8f67YQ0V:b=1,l=0,d=0,g=0;fvWnO7Hn:b=0,l=0,d=0,g=0;ZehRzCbH:b=1,l=0,d=0,g=0;xcHVP0Dm:b=1,l=0,d=0,g=0;c9CWHNuQ:b=1,l=0,d=0,g=0;sp2Efgni:b=1,l=0,d=0,g=0;', '2023-07-13');

-- --------------------------------------------------------

--
-- Table structure for table `setting`
--

CREATE TABLE `setting` (
  `meal_rate` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `setting`
--

INSERT INTO `setting` (`meal_rate`) VALUES
(40),
(0);

-- --------------------------------------------------------

--
-- Table structure for table `shopkeeper`
--

CREATE TABLE `shopkeeper` (
  `id` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `tk` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `shopkeeper`
--

INSERT INTO `shopkeeper` (`id`, `name`, `tk`, `created_at`) VALUES
(20, 'Hridoy Karomokar(108) + Mohatamim(110)', 7800, '2023-07-08 18:00:00'),
(19, 'Mehedi(201) + Mobarok(202)', 9570, '2023-07-05 18:00:00'),
(18, 'Ruhul(104) + Mohatamim(110)', 9295, '2023-07-02 18:00:00'),
(21, 'Limon(108) + Mohatamim(110)', 5525, '2023-07-12 04:22:48');

-- --------------------------------------------------------

--
-- Table structure for table `tk`
--

CREATE TABLE `tk` (
  `id` int(11) NOT NULL,
  `border_id` varchar(11) NOT NULL,
  `tk` int(5) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `tk`
--

INSERT INTO `tk` (`id`, `border_id`, `tk`, `created_at`) VALUES
(27, 'FKSbv9DK', 800, '2023-06-24 13:52:14'),
(28, 'BRC0LLKK', 1000, '2023-07-02 15:00:41'),
(29, 'aP2krUFj', 1000, '2023-07-02 15:00:41'),
(30, 'sW6rLZ8L', 1000, '2023-07-02 15:00:41'),
(31, 'gwPHcPrW', 1000, '2023-07-02 15:00:41'),
(32, 'Y3JM7KT3', 1000, '2023-07-02 15:00:41'),
(33, 'TDlw3rSg', 1000, '2023-07-02 15:00:41'),
(34, 'bVxCr9ow', 1000, '2023-07-02 15:00:41'),
(35, 'ixHC75AT', 1000, '2023-07-02 15:00:41'),
(36, 'vtAsOS2l', 1000, '2023-07-02 15:00:41'),
(37, 'lxWRGLLO', 1000, '2023-07-02 15:00:41'),
(38, 'vHVDJcaI', 1000, '2023-07-02 15:00:41'),
(39, 'oMoCjsT6', 1000, '2023-07-02 15:00:41'),
(40, 'YdRFQn6O', 1000, '2023-07-02 15:00:41'),
(41, 'vBnMoB75', 1000, '2023-07-02 15:00:41'),
(42, '4sfaVK0d', 1000, '2023-07-02 15:00:41'),
(43, '6Iwxtj2U', 1000, '2023-07-02 15:00:41'),
(44, 'xcHVP0Dm', 1000, '2023-07-02 15:07:07'),
(45, 'c9CWHNuQ', 1000, '2023-07-02 15:22:00'),
(46, 'ZehRzCbH', 200, '2023-07-02 15:22:37'),
(47, 'XD5j5VeO', 1000, '2023-07-02 15:23:22'),
(48, 'mOBSdhma', 1000, '2023-07-02 15:23:49'),
(49, 'um1tyNgm', 1000, '2023-07-02 15:24:25'),
(50, 'TLIHdCwN', 1000, '2023-07-02 15:25:01'),
(51, '9LQ9eUwn', 400, '2023-07-02 15:25:46'),
(52, '30wDyQEy', 1200, '2023-07-02 15:27:31'),
(53, 'e4ZSfi8w', 500, '2023-07-02 15:28:12'),
(54, 'z1rfMqLv', 200, '2023-07-02 15:28:43'),
(55, 'fvWnO7Hn', 1000, '2023-07-02 15:29:14'),
(56, 'OAO70lxY', 500, '2023-07-02 15:49:35'),
(57, 'pjymIFv3', 500, '2023-07-03 05:15:03'),
(58, 'VU4Uq7YJ', 0, '2023-07-03 15:32:43'),
(59, 'NE6KrKRJ', 0, '2023-07-03 15:33:10'),
(60, 'h8ZtNpzt', 0, '2023-07-03 15:33:37'),
(61, 'Sg9Baf4S', 500, '2023-07-03 15:34:02'),
(62, 'VzfhksjI', 0, '2023-07-03 15:34:55'),
(63, 'IjUAFW8z', 0, '2023-07-03 15:36:10'),
(64, 'TeglWfYx', 0, '2023-07-03 15:39:38'),
(65, 'ywUh7B4R', 500, '2023-07-03 15:40:03'),
(66, 'poYY4yzN', 0, '2023-07-04 14:51:08'),
(67, 'MzNIKRh4', 0, '2023-07-04 14:52:22'),
(68, 'CxLjzxUU', 0, '2023-07-04 14:53:07'),
(69, 'MIribe3l', 0, '2023-07-04 14:53:34'),
(70, '8f67YQ0V', 0, '2023-07-04 14:54:09'),
(71, 'BCMa1Yb1', 0, '2023-07-05 11:25:09'),
(72, 'BCMa1Yb1', 1000, '2023-07-05 14:00:09'),
(73, '8f67YQ0V', 300, '2023-07-05 14:00:32'),
(74, 'CxLjzxUU', 1000, '2023-07-05 14:01:00'),
(75, 'MzNIKRh4', 1000, '2023-07-05 14:01:23'),
(76, 'NE6KrKRJ', 700, '2023-07-05 14:01:48'),
(77, 'TeglWfYx', 1000, '2023-07-05 14:03:02'),
(78, 'TLIHdCwN', 400, '2023-07-05 14:03:17'),
(79, 'MIribe3l', 1000, '2023-07-05 14:38:26'),
(80, 'poYY4yzN', 1000, '2023-07-05 16:48:29'),
(81, 'ZehRzCbH', 800, '2023-07-06 04:08:24'),
(82, 'C6THBEoX', 1000, '2023-07-06 09:04:50'),
(83, '3gVZtbqq', 0, '2023-07-06 14:26:13'),
(84, 'MhlGpflU', 0, '2023-07-06 14:32:32'),
(85, 'MhlGpflU', 500, '2023-07-07 07:03:50'),
(86, 'EELncfZT', 0, '2023-07-07 12:18:09'),
(87, 'xSaiO6U4', 0, '2023-07-07 12:18:09'),
(88, 'IjUAFW8z', 1000, '2023-07-08 15:53:32'),
(89, 'EELncfZT', 1000, '2023-07-08 16:03:24'),
(90, 'e4ZSfi8w', 500, '2023-07-08 16:03:41'),
(91, 'VzfhksjI', 1000, '2023-07-08 16:04:17'),
(92, 'MhlGpflU', 500, '2023-07-08 16:04:39'),
(93, '9LQ9eUwn', 1000, '2023-07-08 16:05:27'),
(94, 'NE6KrKRJ', 300, '2023-07-08 16:06:06'),
(95, 'ywUh7B4R', 500, '2023-07-08 16:06:34'),
(96, 'VU4Uq7YJ', 1000, '2023-07-09 09:30:47'),
(97, 'eWlWS2j7', 500, '2023-07-09 13:46:53'),
(98, 'sp2Efgni', 0, '2023-07-09 13:47:18'),
(99, 'kvJhGvvu', 0, '2023-07-09 13:55:05'),
(100, 'g1TWRfv8', 300, '2023-07-10 10:24:25'),
(101, 'h8ZtNpzt', 500, '2023-07-10 10:24:41'),
(102, 'bHAPNtBC', 0, '2023-07-10 10:53:51'),
(103, 'z1rfMqLv', 1000, '2023-07-10 15:23:20'),
(104, 'Sg9Baf4S', 500, '2023-07-10 19:26:17'),
(105, 'bHAPNtBC', 400, '2023-07-11 07:59:33'),
(106, '8f67YQ0V', 500, '2023-07-11 07:59:58'),
(108, 'TLIHdCwN', 100, '2023-07-11 08:08:15'),
(109, 'g1TWRfv8', 100, '2023-07-11 08:08:37'),
(110, 'sp2Efgni', 400, '2023-07-11 14:27:40'),
(111, '3gVZtbqq', 700, '2023-07-11 14:28:33'),
(112, 'kvJhGvvu', 500, '2023-07-11 15:19:04'),
(113, 'h8ZtNpzt', 100, '2023-07-11 16:41:22'),
(114, 'um1tyNgm', 100, '2023-07-11 16:54:46'),
(115, 'OAO70lxY', 500, '2023-07-11 17:04:14'),
(116, 'TeglWfYx', 100, '2023-07-11 17:04:44'),
(117, 'VU4Uq7YJ', 200, '2023-07-12 04:19:54');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `border`
--
ALTER TABLE `border`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `extra`
--
ALTER TABLE `extra`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `meal`
--
ALTER TABLE `meal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shopkeeper`
--
ALTER TABLE `shopkeeper`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tk`
--
ALTER TABLE `tk`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `border`
--
ALTER TABLE `border`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `extra`
--
ALTER TABLE `extra`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `meal`
--
ALTER TABLE `meal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `shopkeeper`
--
ALTER TABLE `shopkeeper`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tk`
--
ALTER TABLE `tk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=118;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

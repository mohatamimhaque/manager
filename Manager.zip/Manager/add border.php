<?php include 'include/header.php'; ?>
   <link rel="stylesheet" href="assets/css/css.css">
   <link rel="stylesheet" href="assets/css/style.css">
   
     	<div class="main-w3layouts wrapper">
		
		<div class="main-agileinfo">
			<div class="agileits-top">
				<div>
			<input class="text" type="text" name="name" id="name" placeholder="Name" required="">
				
					<input class="text w3lpass" type="text" name="room" placeholder="Room no" required="" id="room">
					<input class="text w3lpass" type="text" name="mobile" placeholder="Mobile Number" required="" id="mobile">
					<input class="text w3lpass" type="text" name="tk" placeholder="TK" required="" id="tk">
					<p style="display:none" class="text-danger mandatory">All fields are mandatory</p>
					<input id='add' type="submit" value="Add Border">
				</div>
				
			</div>
		</div>


		<ul class="colorlib-bubbles">
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
		</ul>
	</div>


<script>
  $(document).on('click', '#add', function(){
    
    
      var name = $('#name').val();
      var room = $('#room').val();
      var mobile = $('#mobile').val();
      var tk = $('#tk').val();
      var fd = new FormData();
      fd.append('operation','add_user');
            fd.append('name',name);
            fd.append('room',room);
            fd.append('mobile',mobile);
            fd.append('tk',tk);
     
      if(name !=='' && room !=='' && mobile!=='' && tk !==''){
        $.ajax({
            url:"ajax/code.php",
              type: 'post',
              data: fd,
              contentType: false,
              processData: false,
              success: function(response){
               alert(response)
                location.reload();
              }
          });
      }
      else{
        $('.mandatory').css("display",'flex')
      }
/**/
})
</script>

<?php include 'include/footer.php'; ?>
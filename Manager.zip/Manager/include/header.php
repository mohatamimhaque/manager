<?php include('ajax/config.php');?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Border add</title>
  <style>
    :root{
  --nav:#FFAA33;
  --nav-icon:#FFF5EE;
  --icon:#ffd79d;
  --font:#4a536b;
  --col1:#320d3e;
  --border:#DAF7A6;
  
}

  </style>
   
 <script src="assets/js/jquery.js"></script>
 <script src="assets/js/jquery-ui.min.js"></script>
   <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/table.css">
   <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link rel="stylesheet" href="assets/css/font-awesome/css/font-awesome.min.css">

    <link rel="stylesheet" href="assets/css/tailwind.min.css">
    <link rel="stylesheet" href="assets/css/google-font.css">
    <link rel="stylesheet" href="assets/css/mobile-control.css">
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
 <nav>
   <div id="menu_icon">
     <div class="bar">
       <div></div>
       <div></div>
       <div></div>
     </div>
   </div>
   <div id="search_icon">
     <span class="material-icons">search</span>
   </div>
   <div class="search_bar">
     <div style="position:relative">
        <input type="search" id="search">
         <div class="close">
        <span class="material-icons">close</span>
      </div>
     </div>
     
   </div>
 </nav>
  <div class="sidebar">
    <div class="menu">
      <div class="nav-link"><a href="index.php">Manager</a></div>
       <div class="nav-link"><a href="add border.php">Add Border</a></div>
       <div class="nav-link"><a href="add meal.php">Add Meal </a>
       </div>
              <div class="nav-link"><a href="cost.php">cost </a>
       </div>

       <div class="nav-link"><a href="daily meal.php">Daily Meal</a></div>
              <div class="nav-link"><a href="shopkeeper.php">Shopkeeper</a></div>
       <div class="nav-link"><a href="summary.php">Summery</a></div>
       <div class="nav-link"><a href="## #">Settings</a></div>
       <div class="close">
        <span class="material-icons">close</span>
      </div>
    
     
      
    </div>
      <div class="extra"></div>
  </div>
  
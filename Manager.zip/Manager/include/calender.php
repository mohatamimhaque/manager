 
<div id="app" class="flex justify-center p-10">
  <div class="flex flex-wrap w-full lg:w-1/2 justify-center">
    <div class="flex w-full justify-center text-white uppercase tracking-wide font-semibold text-sm">
      <span class="text-gray-900 py-2">
        {{ month.join('/') }} {{ year.join('/') }}
      </span>
    </div>
    <div class="flex w-full justify-center">
      <div class="flex justify-center text-white text-center px-4 py-2 m-2">
        <div 
          class="self-center text-center rounded-lg"
          tabindex="0"
          role="button" 
          aria-pressed="false"
        >
          <div class="cursor-default flex items-center">
            <svg 
             class="fill-current h-4 w-4" 
             xmlns="http://www.w3.org/2000/svg" 
             viewBox="0 0 20 20"
             style="transform: rotate(90deg);"
            >
              <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"></path>
            </svg>
          </div>
        </div>
      </div>
      <div class="text-gray-700 text-center">
        <div class="flex justify-center items-center bg-gray-600">
          <div class="flex justify-center text-gray-200 text-center bg-gray-600 w-10 h-10 rounded-full px-4 py-2 m-2">
            <span class="self-center text-sm">M</span>
          </div>
          <div class="flex justify-center text-gray-200 text-center bg-gray-600 w-10 h-10 rounded-full px-4 py-2 m-2">
            <span class="self-center text-sm">T</span>
          </div>
          <div class="flex justify-center text-gray-200 text-center bg-gray-600 w-10 h-10 rounded-full px-4 py-2 m-2">
            <span class="self-center text-sm">W</span>
          </div>
          <div class="flex justify-center text-gray-200 text-center bg-gray-600 w-10 h-10 rounded-full px-4 py-2 m-2">
            <span class="self-center text-sm">T</span>
          </div>
          <div class="flex justify-center text-gray-200 text-center bg-gray-600 w-10 h-10 rounded-full px-4 py-2 m-2">
            <span class="self-center text-sm">F</span>
          </div>
          <div class="flex justify-center text-gray-200 text-center bg-gray-600 w-10 h-10 rounded-full px-4 py-2 m-2">
            <span class="self-center text-sm">S</span>
          </div>
          <div class="flex justify-center text-gray-200 text-center bg-gray-600 w-10 h-10 rounded-full px-4 py-2 m-2">
            <span class="self-center text-sm">S</span>
          </div>
        </div>
      </div>
      <div class="flex justify-center text-white text-center px-4 py-2 m-2">
        <div 
          class="self-center text-center rounded-lg"
          tabindex="0"
          role="button" 
          aria-pressed="false"
        >
          <div class="cursor-default flex items-center">
            <svg 
             class="fill-current h-4 w-4" 
             xmlns="http://www.w3.org/2000/svg" 
             viewBox="0 0 20 20"
             style="transform: rotate(-90deg);"
            >
              <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"></path>
            </svg>
          </div>
        </div>
      </div>
    </div>
    <div class="flex w-full justify-center">
      <div 
        class="flex justify-center text-gray-700 text-center bg-gray-400 hover:bg-gray-800 hover:text-gray-200 px-4 py-2 m-2 cursor-pointer"
        v-on:click="getPreviousWeek()"
      >
        <div 
          class="self-center text-center rounded-lg"
          tabindex="0"
          role="button" 
          aria-pressed="false"
        >
          <div class="flex items-center">
            <svg 
             class="fill-current h-4 w-4" 
             xmlns="http://www.w3.org/2000/svg" 
             viewBox="0 0 20 20"
             style="transform: rotate(90deg);"
            >
              <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"></path>
            </svg>
          </div>
        </div>
      </div>
      <div class="text-gray-700 text-center">
        <div class="flex justify-center items-center bg-gray-600">
          <div
            v-for="(day, index) in week"
            v-bind:key="index"
            class="flex justify-center text-center w-10 h-10 rounded-full px-4 py-2 m-2"
            v-bind:class="{ 
                            'bg-gray-800 text-gray-300 hover:bg-gray-800 hover:text-gray-300 cursor-not-allowed': day.active && !day.currentDayToday, 
                            'bg-gray-400 text-gray-800 hover:bg-gray-800 hover:text-gray-300 cursor-pointer': !day.active && !day.currentDayToday,
                            'bg-gray-900 text-gray-200 hover:bg-gray-900 hover:text-gray-200 cursor-not-allowed': day.currentDayToday
                          }"
            v-on:click="setActiveDay(day)"
          >
            <span class="self-center text-xs">{{ day.ordinal }}</span>
          </div>
        </div>
      </div>
      <div 
        class="flex justify-center text-gray-700 text-center bg-gray-400 hover:bg-gray-800 hover:text-gray-200 px-4 py-2 m-2 cursor-pointer"
        v-on:click="getNextWeek()"
      >
        <div 
          class="self-center text-center rounded-lg"
          tabindex="0"
          role="button" 
          aria-pressed="false"
        >
          <div class="flex items-center">
            <svg 
             class="fill-current h-4 w-4" 
             xmlns="http://www.w3.org/2000/svg" 
             viewBox="0 0 20 20"
             style="transform: rotate(-90deg);"
            >
              <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"></path>
            </svg>
          </div>
        </div>
      </div>
    </div>
    <div class="flex w-full justify-center text-white uppercase tracking-wide font-semibold text-sm my-4">
      <span class="day_show text-gray-900 py-2">
     {{ selectedDate.actual}}
     
     </span>
    </div>
  </div>
</div>
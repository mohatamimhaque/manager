<div id="modal" class=''>
    <div class="div">
      <div class="close">
        <div></div>
      </div>
     
      <p>You are want to add balance</p>
       <h6></h6>
       <input type="text">
      <button value='ok'>Confirm</button>
    </div>
  </div>
  <style>
     #modal{
    position: fixed;
  width:100%;
  height:100vh;
  z-index:40;
  background:rgba(0,0,0,0.5);
  overflow: hidden;
  display:none;
  top:0;
  left:0;
  align-items:center;
  justify-content: center;
  
  }
  #modal.active{
    display:flex;
  }
  #modal .div{
    position: relative;
    background: white;
    padding:24px 20px;
    width:80%;
    border-radius:8px;
    box-shadow:0 0 12 rgba(0,0,0,0.28);
  }
  #modal .close{
    width:24px;
    height: 24px;
    
    padding: 2px;
    position:absolute;
    bottom:4px;
    left:8px;
    display:flex;
    align-items: center;
    justify-content: center;
  }
   #modal button{
     font-size: 16px;
     font-weight: 700;
     color: rgba(0,0,0,0.5);
   border: none;
    background: none;
    padding: 5px;
    position:absolute;
    bottom:4px;
    right:8px;
    display:flex;
    align-items: center;
    justify-content: center;
  }
  #modal .close div{
    position: relative;
    width:3px;
    height: 18px;
    background: rgba(0,0,0,0.5);
    border-radius: 2px;
    transform: rotate(45deg);
  }
    #modal .close div:after{
      content: '';
    position: absolute;
    width:3px;
    height: 18px;
    background: rgba(0,0,0,0.5);
    border-radius: 2px;
    transform: rotate(-90deg);
  }
  #modal p{
    
    font-size: 14px;
    color: rgba(0,0,0,0.8);
    text-align: center;
  }
  #modal input{
    border : 1px solid var(--border);
  border-radius: 4px;
  outline: none;
  
    
  }
  #modal .div{
    display:flex;
    flex-direction:column;
    justify-content:center;
    align-items: center;
  }
  #modal h6,#modal input{
    font-size: 14px;
    color: rgba(0,0,0,0.8);
    text-align: center;
    
    color:pink;
    margin-bottom:12px;
    
  }
  #modal input{
    border:1px solid pink;
  }
   .delete{
     position: absolute;
     bottom:10px;
     right:0px;
     padding:6px 8px;
     color: rgba(0,0,0,0.7);
     background:white;
     border: none;
     border-radius: 2px;
     font-size: 18px;
     font-weight: 700;
     z-index:20;
     box-shadow: 0 0 2px rgba(0,0,0,0.2);
     display:flex;
     
     
   }
   .delete.active{
     display:flex;
   }
  </style>
  <script>
  addModal();
  function addModal(){
    
  
 $('#modal .close').click(function(){
     $('#modal').removeClass('active');
   })
   $('.addTk').click(function(){
    let thisclicked = $(this);
    let id = thisclicked.val();
    let title = thisclicked.closest('tr').find('td:first-child div').text().trim();
    
    $('#modal').addClass('active');
    $('#modal button').val(id);
    
    $('#modal h6').text(title);
    
    
    
    
  })
  $('#modal button').click(function(){
     let thisclicked = $(this);
     let id = thisclicked.val();
     let tk = $('#modal input').val();
     if(tk!==''){
       
       var fd = new FormData();
  fd.append('operation','tk_update');
  fd.append('id',id);
  fd.append('tk',tk);
  
  
  $.ajax({
            url:"ajax/code.php",
              type: 'post',
              data: fd,
              contentType: false,
              processData: false,
              success: function(response){
               alert(response)
                location.reload();
              }
          });
     }
     //$('#modal').removeClass('active');
   })
}
  </script>
  
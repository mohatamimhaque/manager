 

  <script src="assets/js/bootstrap.min.js"></script>
  <script src="assets/js/script.js"></script>
</body>
</html>

<?php
//mysqli_query($con,"Delete FROM border");
//mysqli_query($con,"delete FROM meal");
//mysqli_query($con,"Delete FROM tk");
//mysqli_query($con,"Delete FROM shopkeeper");

?>
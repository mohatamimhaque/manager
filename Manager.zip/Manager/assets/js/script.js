    $(document).ready(function() {
     $(".search_bar .close").click(function() {
        $(".search_bar").removeClass("active");
      });
      $("#search_icon").click(function() {
        $(".search_bar").addClass("active");
      });
     
     
     
     
      $(".sidebar .extra").click(function() {
        $(".sidebar").removeClass("active");
        
      });
      $(".sidebar .close").click(function() {
        $(".sidebar").removeClass("active");
      });
      
      $("#menu_icon").click(function() {
      
        $(".sidebar").addClass("active");
      });

    });
    
   
   
  
    
    
    
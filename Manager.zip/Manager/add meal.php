<?php include 'include/header.php'; ?>

	<section class="ftco-section">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">

					<div class="table-wrap">
						<table class="table">
						  <thead class="thead-primary">
						    <tr>
						    	<th>Name</th>
						      <th>Breakfast <input type="checkbox" id="breakfast" checked>
								</th>
						      <th>Launch <input type="checkbox" id="launch" checked>
								</th>
						      <th>Dinner <input type="checkbox" id="dinner" checked>
								</th>
						      <th>Guest</th>
						    </tr>
						  </thead>
						  <tbody>
						                                 <?php
                             $border =mysqli_query($con,"SELECT * FROM border order by room");

             $serial=0;
                             if(mysqli_num_rows($border) > 0){
                               foreach($border as $row){
                        $serial++;
                     ?>   
						    <tr class="alert person" role="alert" id="<?= $row['unique_id']?>">
						    	<td>
						    	  <?= $serial ?>.
						    	  <?= $row['name']?>(<?= $row['room']?>)</td>
						      <td>
						    		<label class="checkbox-wrap checkbox-primary">
										  <input type="checkbox" class="breakfast" checked>
										  <span class="checkmark"></span>
										</label>
						      </td>
						      <td>						    		<label class="checkbox-wrap checkbox-primary">
										  <input type="checkbox" class='launch' checked>
										  <span class="checkmark"></span>
										</label></td>
						      <td>						    		<label class="checkbox-wrap checkbox-primary">
										  <input type="checkbox" class="dinner" checked>
										  <span class="checkmark"></span>
										</label></td>
						      <td class="quantity">
					        	<div class="input-group">
				             	<input type="text" name="guest" class="guest form-control input-number" value="0" min="0" max="100">
				          	</div>
				          </td>

						    </tr>
		      <?php }} ?>

						  </tbody>
						</table>
									<button id="add_meal" type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">add meal</button>

					</div>
				</div>
			</div>
		</div>
	</section>

	

<!-- Button trigger modal -->

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style=''>
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Total Meal</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
<div class="border-info">
 
  <div class="item">
    <p class="text-primary">Sokal</p>
    <p class="text-info">:<div class="sokal">12</div></p>
  </div>
   <div class="item">
    <p class="text-primary">Dupur</p>
    <p class="text-info">:<div class="dupur">12</div></p>
  </div>
   <div class="item">
    <p class="text-primary">Rat</p>
    <p class="text-info">:<div class="rat">12</div></p>
  </div>
     <div class="item">
    <p class="text-primary">Guest</p>
    <p class="text-info">:<div class="guest">12</div></p>
  </div>
    

   
  
</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button id="submit" type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>


<script>
document.querySelector('#add_meal').addEventListener('click',()=>{
let person = document.getElementsByClassName('person');
  let breakfast,launch,dinner,meal;
  let sokal= 0;
  let dupur =0;
  let rat =0;
   let  gues = 0;
  for(let i=0;i<person.length;i++){
    meal=0;
    id=document.getElementById(person[i].id);
    
    breakfast = id.querySelector('.breakfast');
   launch = id.querySelector('.launch');
    dinner = id.querySelector('.dinner');
    guest = id.querySelector('.guest').value;
    if(breakfast.checked){
      sokal+=1;
    }
    if(launch.checked){
      dupur+=1;
    }
    if(dinner.checked){
      rat+=1;
    }
    gues+=parseFloat(guest);
  }
  $(".sokal").html(sokal);
  $(".dupur").html(dupur);
  $(".rat").html(rat);
  $(".guest").html(gues);
  })
document.querySelector('#submit').addEventListener('click',()=>{
 

var person = document.getElementsByClassName('person');
  let id,breakfast,launch,dinner,meal;
  let today_meal='';
  let daily_meal='';
  for(let i=0;i<person.length;i++){
    meal=0;
    id=document.getElementById(person[i].id);
    
    breakfast = id.querySelector('.breakfast');
   launch = id.querySelector('.launch');
    dinner = id.querySelector('.dinner');
    guest = id.querySelector('.guest').value;
    if(breakfast.checked){
      meal+=0.5;
      breakfast='1';
    }
    else{
      breakfast='0';
    }
    if(launch.checked){
      meal+=1;
      launch='1';
    }
    else{
      launch='0';
    }
    if(dinner.checked){
      meal+=1;
      dinner='1';
    }
    else{
      dinner='0';
    }
    meal+=parseFloat(guest);
    today_meal += `${person[i].id}:${meal};`;

    daily_meal +=`${person[i].id}:b=${breakfast},l=${launch},d=${dinner},g=${guest};`;
    
    
   }
  var fd = new FormData();
  fd.append('operation','add_meal');
  fd.append('daily_meal',daily_meal);
  fd.append('today_meal',today_meal);
 // alert(today_meal);
  //alert(daily_meal)
  $.ajax({
            url:"ajax/code.php",
              type: 'post',
              data: fd,
              contentType: false,
              processData: false,
              success: function(response){
               alert(response);
                location.reload();
              }
          });
  
})
</script>
  
 <script>
const breakfast = document.querySelector('#breakfast');
const subbreakfast = document.querySelectorAll('.breakfast');
breakfast.addEventListener('click', function () {
  const isChecked = this.checked;
 subbreakfast.forEach(function (checkbox){
    checkbox.checked = isChecked;
  });
});
subbreakfast.forEach(function (checkbox) {
  checkbox.addEventListener('click', function () {
    if (!this.checked) {
      checkAll.checked = false;
    }
  });
});
const launch = document.querySelector('#launch');
const sublaunch = document.querySelectorAll('.launch');
launch.addEventListener('click', function () {
  const isChecked = this.checked;
 sublaunch.forEach(function (checkbox){
    checkbox.checked = isChecked;
  });
});
sublaunch.forEach(function (checkbox) {
  checkbox.addEventListener('click', function () {
    if (!this.checked) {
      checkAll.checked = false;
    }
  });
});
const dinner = document.querySelector('#dinner');
const subdinner= document.querySelectorAll('.dinner');
dinner.addEventListener('click', function () {
  const isChecked = this.checked;
 subdinner.forEach(function (checkbox){
    checkbox.checked = isChecked;
  });
});
subdinner.forEach(function (checkbox) {
  checkbox.addEventListener('click', function () {
    if (!this.checked) {
      checkAll.checked = false;
    }
  });
});
</script>



<?php include 'include/footer.php'; ?>
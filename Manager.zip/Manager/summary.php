<?php include 'include/header.php';
foreach(mysqli_query($con,"SELECT sum(tk) FROM border") as $r){;
$total_tk = $r['sum(tk)'];
}
foreach(mysqli_query($con,"SELECT sum(total_meal) FROM border") as $r){;
$total_meal = $r['sum(total_meal)'];
}
foreach(mysqli_query($con,"SELECT sum(tk) FROM shopkeeper") as $r){;
$total_cost = $r['sum(tk)'];
}
foreach(mysqli_query($con,"SELECT sum(tk) FROM extra") as $r){;
$extra = $r['sum(tk)'];
}
$total_cost = $total_cost + $extra;
$total_bajar = mysqli_num_rows(mysqli_query($con,"SELECT * FROM shopkeeper"));
$remainig = $total_tk - $total_cost;
$meal_rate = $total_cost / $total_meal;


?>

<div class="border-info">
  <div class="item">
    <p class="text-primary">Total Tk</p>
    <p class="text-info">: <?= $total_tk?></p>
  </div>
    <div class="item">
    <p class="text-primary">Total Meal</p>
    <p class="text-info">: <?= $total_meal?></p>
  </div>
  <div class="item">
    <p class="text-primary">Total Cost</p>
    <p class="text-info">: <?= $total_cost?></p>
  </div>
  
   <div class="item">
    <p class="text-primary"> Remaining </p>
    
    <p class="text-info">: <?= $remainig?></p>
  </div>
   <div class="item">
    <p class="text-primary">Meal Rate:</p>
    <p class="text-info">: <?= $meal_rate ?></p>
  </div>
   <div class="item">
    <p class="text-primary">Total Bajar:</p>
    <p class="text-info">: <?= $total_bajar ?></p>
  </div>

   
  
</div>
<div id="data">
  
</div>



<?php  include 'include/footer.php'; 


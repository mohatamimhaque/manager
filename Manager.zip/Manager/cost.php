<?php include 'include/header.php'; ?>
<style>
  input:focus {outline: none;}
#ui-datepicker-div {
	display: none;
	background-color: #fff;
	box-shadow: 0 0.125rem 0.5rem rgba(0,0,0,0.1);
	margin-top: 0.25rem;
	border-radius: 0.5rem;
	padding: 0.5rem;
}
table {
	border-collapse: collapse;
	border-spacing: 0;
}
.ui-datepicker-calendar thead th {
	padding: 0.25rem 0;
	text-align: center;
	font-size: 0.75rem;
	font-weight: 400;
	color: #78909C;
}
.ui-datepicker-calendar tbody td {
	width: 2.5rem;
	text-align: center;
	padding: 0;
}
.ui-datepicker-calendar tbody td a {
	display: block;
	border-radius: 0.25rem;
	line-height: 2rem;
	transition: 0.3s all;
	color: #546E7A;
	font-size: 0.875rem;
	text-decoration: none;
}
.ui-datepicker-calendar tbody td a:hover {	
	background-color: #E0F2F1;
}
.ui-datepicker-calendar tbody td a.ui-state-active {
	background-color: #009688;
	color: white;
}
.ui-datepicker-header a.ui-corner-all {
	cursor: pointer;
	position: absolute;
	top: 0;
	width: 2rem;
	height: 2rem;
	margin: 0.5rem;
	border-radius: 0.25rem;
	transition: 0.3s all;
}
.ui-datepicker-header a.ui-corner-all:hover {
	background-color: #ECEFF1;
}
.ui-datepicker-header a.ui-datepicker-prev {	
	left: 0;	
	background: url("data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMyIgdmlld0JveD0iMCAwIDEzIDEzIj48cGF0aCBmaWxsPSIjNDI0NzcwIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik03LjI4OCA2LjI5NkwzLjIwMiAyLjIxYS43MS43MSAwIDAgMSAuMDA3LS45OTljLjI4LS4yOC43MjUtLjI4Ljk5OS0uMDA3TDguODAzIDUuOGEuNjk1LjY5NSAwIDAgMSAuMjAyLjQ5Ni42OTUuNjk1IDAgMCAxLS4yMDIuNDk3bC00LjU5NSA0LjU5NWEuNzA0LjcwNCAwIDAgMS0xLS4wMDcuNzEuNzEgMCAwIDEtLjAwNi0uOTk5bDQuMDg2LTQuMDg2eiIvPjwvc3ZnPg==");
	background-repeat: no-repeat;
	background-size: 0.5rem;
	background-position: 50%;
	transform: rotate(180deg);
}
.ui-datepicker-header a.ui-datepicker-next {
	right: 0;
	background: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMyIgdmlld0JveD0iMCAwIDEzIDEzIj48cGF0aCBmaWxsPSIjNDI0NzcwIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik03LjI4OCA2LjI5NkwzLjIwMiAyLjIxYS43MS43MSAwIDAgMSAuMDA3LS45OTljLjI4LS4yOC43MjUtLjI4Ljk5OS0uMDA3TDguODAzIDUuOGEuNjk1LjY5NSAwIDAgMSAuMjAyLjQ5Ni42OTUuNjk1IDAgMCAxLS4yMDIuNDk3bC00LjU5NSA0LjU5NWEuNzA0LjcwNCAwIDAgMS0xLS4wMDcuNzEuNzEgMCAwIDEtLjAwNi0uOTk5bDQuMDg2LTQuMDg2eiIvPjwvc3ZnPg==');
	background-repeat: no-repeat;
	background-size: 10px;
	background-position: 50%;
}
.ui-datepicker-header a>span {
	display: none;
}
.ui-datepicker-title {
	text-align: center;
	line-height: 2rem;
	margin-bottom: 0.25rem;
	font-size: 0.875rem;
	font-weight: 500;
	padding-bottom: 0.25rem;
}
.ui-datepicker-week-col {
	color: #78909C;
	font-weight: 400;
	font-size: 0.75rem;
}
</style>
   <link rel="stylesheet" href="assets/css/css.css">
   <link rel="stylesheet" href="assets/css/style.css">
   
     	<div class="main-w3layouts wrapper">
		
		<div class="main-agileinfo bajar">
			<div class="agileits-top">
<p stye="font-size:40px" class="text-center text-danger">Bajar</p>
				<div>
		<input class="w3lpass text" type="text" name="date" placeholder="date" id="datepicker" autocomplete="off" required="">
			<input class="text w3lpass" type="text" name="name" id="f_name" placeholder="First Shopkeeper" required="">
				<input class="text w3lpass" type="text" name="name" id="s_name" placeholder="Second Shopkeeper" required="">
					<input class="text tk w3lpass" type="text" name="tk" placeholder="TK" required="" id="tk">
					<p style="display:none" class="text-danger mandatory">All fields are mandatory</p>
					<input id='add' type="submit" value="Add">
				</div>
				
			</div>
		</div>
			
		<div class="main-agileinfo extra">
			<div class="agileits-top">
			  <p stye="font-size:40px" class="text-center text-danger">Extra</p>
				<div>
			<input class="w3lpass text" type="text" name="date" placeholder="date" id="datepicker2" autocomplete="off" required="">
				<input class="text w3lpass" type="text" name="description" id="description" placeholder="description" required="">
					<input class="text w3lpass" type="text" name="tk" placeholder="TK" required="" id="cost">
					<p style="display:none" class="text-danger mandatory">All fields are mandatory</p>
					<input id='extra' type="submit" value="Add">
				</div>
				
			</div>
		</div>


		<ul class="colorlib-bubbles">
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
		</ul>
	</div>
	
	 	


 
  <script src='assets/js/jquery.min.js'></script>

  <script src='assets/js/jquery-ui.min.js'></script>
  

<script>
// INCLUDE JQUERY & JQUERY UI 1.12.1
$( function() {
	$(".bajar #datepicker").datepicker({
		dateFormat: "yy-mm-dd"
		,	duration: "fast"
	});
	
} );
$( function() {
	$(".extra #datepicker2").datepicker({
		dateFormat: "yy-mm-dd"
		,	duration: "fast"
	});
} );
$(document).on('click', '#extra', function(){
    let date = $('#datepicker2').val();
    let description = $('#description').val();
    let tk = $('#cost').val();
    var fd = new FormData();
    fd.append('operation','extra');
    fd.append('date',date);
    fd.append('description',description);
    fd.append('tk',tk);
    
      $.ajax({
            url:"ajax/code.php",
              type: 'post',
              data: fd,
              contentType: false,
              processData: false,
              success: function(response){
              alert(response)
               location.reload();
              }
          });

    
    
    
})
  $(document).on('click', '#add', function(){
    var f_name = $('#f_name').val();
    var s_name = $('#s_name').val();
    var tk = $('#tk').val();
    let date = $('#datepicker').val();
    if(f_name!==''&&s_name!==''&&tk!=='')
    {var name = f_name + ' + ' +s_name;
    var fd = new FormData();
  
    fd.append('operation','add_shopkeeper');
    fd.append('date',date);
    fd.append('name',name);
    fd.append('tk',tk);
    
    $.ajax({
            url:"ajax/code.php",
              type: 'post',
              data: fd,
              contentType: false,
              processData: false,
              success: function(response){
               alert(response)
               location.reload();
              }
          });
    
     
    }
    else{
        $('.mandatory').css("display",'flex')
      }
    
      
})
</script>

<?php include 'include/footer.php'; ?>
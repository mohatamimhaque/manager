<?php include 'include/header.php';
if(isset($_GET["id"])){
  $id = $_GET["id"];
  foreach(mysqli_query($con,"SELECT meal_rate FROM setting LIMIT 1") as $r){
		  $rate = floatval($r['meal_rate']);
						          }
						          
						               
						                         
						                $rate = 40.48;                 
                             $border =mysqli_query($con,"SELECT * FROM border where unique_id = '$id'");

     
                             if(mysqli_num_rows($border) > 0){
                               foreach($border as $row){
                     ?>   



<div class="border-info">
  <div class="item">
    <p class="text-primary">Name</p>
    <p class="text-info">: <?= $row['name']?></p>
  </div>
    <div class="item">
    <p class="text-primary">Room</p>
    <p class="text-info">: <?= $row['room']?></p>
  </div>
  <div class="item">
    <p class="text-primary">Mobile</p>
    <p class="text-info">: <?= $row['mobile']?></p>
  </div>
   <div class="item">
    <p class="text-primary"> Total Meal </p>
    <p class="text-info">: <?= $row['total_meal']?></p>
  </div>
  
   <div class="item">
    <p class="text-primary">Gave Money:</p>
    <p class="text-info">: <?= $row['tk']?></p>
  </div>
   <div class="item">
    <p class="text-primary">Money Eaten:</p>
    <p class="text-info">: <?php 
    				          echo floatval($row['total_meal'])*$rate;
    				          
    
    ?></p>
  </div>
   <div class="item">
    <p class="text-primary">Remaining</p>
    <p class="text-info">: <?php 
    echo floatval($row['tk']) - floatval($row['total_meal'])*$rate;?></p>
  </div>
     <div class="item">
   <p><button value="<?= $row['unique_id']?>" style='text-align:start;background:none;cursor:pointer;outline:none;width:100%' class="text-primary addTk">Add Tk</button></p>
    <p class="text-info"><input style="border:2px solid var(--border);border-radius:4px;outline:none" type="text"></p>
  </div>
  
   
    <div class="item">
    <p class="text-primary">Details</p>
    <select name="" class="text-info" id="details">
      <option value="border_meals">Meals</option>
      <option value="border_tk">Tk</option>
      </select>
 
  </div>
  
  
</div>
<div id="data">
  
</div>
 <?php }}?> 
 
  <?php }?> 

<script>

  $('#details').change(function() {

    details($(this).val());
  });




details('border_meals')
function details(operation){
       var fd = new FormData();
       fd.append('id',$('.addTk').val());
  fd.append('operation',operation);
  
  
  
  $.ajax({
            url:"ajax/code.php",
              type: 'post',
              data: fd,
              contentType: false,
              processData: false,
              success: function(response){
               $('#data').html(response);
                //alert(response)
              }
          });


}


  $('.addTk').click(function(){
     let thisclicked = $(this);
     let id = thisclicked.val();
     let tk = $('.border-info input').val();
    // alert(id);
     if(tk!==''){
       
       var fd = new FormData();
  fd.append('operation','tk_update');
  fd.append('id',id);
  fd.append('tk',tk);
  
  
  $.ajax({
            url:"ajax/code.php",
              type: 'post',
              data: fd,
              contentType: false,
              processData: false,
              success: function(response){
               alert(response);
               location.reload();
              }
          });
     }
     //$('#modal').removeClass('active');
   })
</script>

<?php include 'include/footer.php'; 


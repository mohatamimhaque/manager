<?php 
$connect = new PDO("mysql:host=localhost;dbname=manager", "root", "");

$host = "localhost";
$username = "root";
$password = "";
$database = "manager";

$con =mysqli_connect("$host","$username","$password","$database",);



  
?>
  


<?php include 'config.php'; ?>
<table class="table table-stripe" style="text-align:center;color:white" id="example">
<thead>
  <tr>
    <th  style="color:white">সিরিয়াল</th>
    <th  style="color:white">রুম</th>
    <th style="color:white">নাম</th>
    <th  style="color:white">মিল</th>
    <th  style="color:white">টাকা দিছে</th>
    <th  style="color:white">খরচ</th>
    <th  style="color:white">বিবিধ</th>
    <th  style="color:white">ম্যাঃ দিবে</th>
    <th  style="color:white">ম্যাঃ পাবে</th>
    
  </tr>
</thead>

<tbody>
  <?php
                         $s = 0;
                         foreach(mysqli_query($con,"SELECT sum(total_meal) FROM border") as $r){;
                          $total_meal = $r['sum(total_meal)'];
                        }
foreach(mysqli_query($con,"SELECT sum(tk) FROM shopkeeper") as $r){;
$total_cost = $r['sum(tk)'];
}
foreach(mysqli_query($con,"SELECT sum(tk) FROM extra") as $r){;
  $extra = $r['sum(tk)'];
}
$pabo = 0;
$pabe = 0;
$e = mysqli_num_rows(mysqli_query($con,"SELECT * FROM border where room like '1%'"));
$total_cost = $total_cost + $extra;
$meal_rate = $total_cost / $total_meal;
//  echo $meal_rate;
$border =mysqli_query($con,"SELECT * FROM border order by room");


                             if(mysqli_num_rows($border) > 0){
                               foreach($border as $row){
                                 $room = $row['room'];
                                 $name = $row['name'];
                                 $gave_tk = $row['tk'];
                                 $meal = $row['total_meal'];
                                 $cost =number_format(floatval($meal)*$meal_rate, 1, '.', '') ;
                                 if (substr($room, 0, 1) === "1") {
                                   $ex = number_format(floatval(125)/floatval($e), 2, '.', '') ;
                                  } else {
                                    $ex = 0;
}


               $remaining = number_format(floatval($gave_tk) - ($cost + $ex), 2, '.', '');
               

               $s = $s+1;
               
               ?>
<tr>
  
  <td class='print'><?= $s ?></td>
  <td class='print'><?= $room ?></td>
  <td class='print'> <a href='border.php?=<?= $row['unique_id']  ?>'></a> <?= $name ?></a></td>
  <td class='print'><?= $meal ?></td>
  <td class='print'><?= $gave_tk ?></td>
  
  <td class='print'><?= $cost ?></td> 
  <td class='print'><?= $ex ?></td> 
  <?php
  if($remaining>0){
    $pabo = $pabo + $remaining;
    ?>
  <td class='print'><?= $remaining ?></td>
  <td></td>
  <?php
  }
  else{
    $pabe = $pabe + $remaining;
    ?>
   <td> </td>
   <td class='text-danger'><?= $remaining ?></td>
   <?php
  }
  ?>
  
  
</tr>

<?php }
}?>
                         
                        </tbody>
                        <tfoot class='hide'>
                          <th colspan='7'></th>
                          <th><?= $pabo?></th>
                          <th class='text-danger'><?= $pabe?></th>
                        </tfoot>  
                      </table>
<?php
foreach(mysqli_query($con,"SELECT sum(tk) FROM border") as $r){;
$total_tk = $r['sum(tk)'];
}
foreach(mysqli_query($con,"SELECT sum(total_meal) FROM border") as $r){;
$total_meal = $r['sum(total_meal)'];
}
foreach(mysqli_query($con,"SELECT sum(tk) FROM shopkeeper") as $r){;
  $total_cost = $r['sum(tk)'];
}
foreach(mysqli_query($con,"SELECT sum(tk) FROM extra") as $r){;
  $extra = $r['sum(tk)'];
}
$total_cost = $total_cost + $extra;
$total_bajar = mysqli_num_rows(mysqli_query($con,"SELECT * FROM shopkeeper"));
$remainig = $total_tk - $total_cost;
$meal_rate = $total_cost / $total_meal;


?>

<div class="border-info" style='margin-top:50px'>
  <h2 style='text-align:center'>Summary</h2>
  <div class="item">
    <p class="text-primary">Total Tk</p>
    <p class="text-info">: <?= $total_tk?></p>
  </div>
  <div class="item">
    <p class="text-primary">Total Meal</p>
    <p class="text-info">: <?= $total_meal?></p>
  </div>
  <div class="item">
    <p class="text-primary">Total Cost</p>
    <p class="text-info">: <?= $total_cost?></p>
  </div>
  <div class="item">
    <p class="text-primary">Extra</p>
    <p class="text-info">: 125</p>
  </div>
  
  
  <div class="item">
    <p class="text-primary">Meal Rate:</p>
    <p class="text-info">: <?= number_format($meal_rate, 2, '.', '') ?></p>
  </div>
  <div class="item">
    <p class="text-primary">Total Bajar:</p>
    <p class="text-info">: <?= $total_bajar ?></p>
  </div>
  
   
  
</div>

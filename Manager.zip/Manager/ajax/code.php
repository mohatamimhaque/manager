 <?php include 'config.php'; ?>
<?php
if($_POST["operation"] == 'add_user'){
 $name = $_POST["name"];
 $room = $_POST["room"];
 $mobile = $_POST["mobile"];
 $tk = $_POST["tk"];
 
 $unique_id = '';
 while(true){
    $unique_id = '';
    $characters='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    
    for ($k = 0; $k < 8; $k++) {
        $unique_id .= $characters[rand(0, strlen($characters) - 1)];
    }
    $checkId = "SELECT unique_id from border WHERE unique_id='$unique_id'";
    $checkId_run = mysqli_query($con, $checkId);
        if(mysqli_num_rows($checkId_run)>0){
        }
        else{
          break;
        }
  }
 $checkId = "SELECT * from border WHERE mobile='$mobile'";
    $checkId_run = mysqli_query($con, $checkId);
        if(mysqli_num_rows($checkId_run)>0){
          echo 'alredy exits';
        }
        else{ 
  $sql = "INSERT INTO border (name, mobile,unique_id,room,tk)
        VALUES ('$name','$mobile','$unique_id','$room','$tk')";

// execute the SQL query
if (mysqli_query($con, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($con);
}
$sql = "INSERT INTO tk (border_id,tk)
        VALUES ('$unique_id','$tk')";

// execute the SQL query
if (mysqli_query($con, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($con);
}}

 
  
  }
  
  
 
  if($_POST["operation"] == 'add_meal'){
 ;
 $today_meal= $_POST["today_meal"];
 $daily_meal= $_POST["daily_meal"];
 $arr = explode(';',$today_meal);
 array_pop($arr);
 $today = date("Y-m-d");
 
 $checkId = "SELECT * from meal WHERE created_at='$today'";
    $checkId_run = mysqli_query($con, $checkId);
        if(mysqli_num_rows($checkId_run)>0){
          echo 'alredy exits';
        }
        else{
          
 
 foreach ($arr as $val) {
    $each = explode(':',$val);
    $meal = floatval($each[1]);
    $id=$each[0];
    
   mysqli_query($con, "UPDATE border SET total_meal=total_meal+$meal WHERE unique_id = '$id'");
}

$sql = "INSERT INTO meal (today_meal, daily_meal,created_at)
        VALUES ('$today_meal','$daily_meal','$today')";


// execute the SQL query
if (mysqli_query($con, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($con);
}
}


  }
  if($_POST["operation"] == 'tk_update'){
   $id = $_POST["id"];
  // echo $id;
   $tk = intval($_POST["tk"]);
   mysqli_query($con, "update border set tk = tk + $tk where unique_id = '$id'");
   $sql = "INSERT INTO tk (border_id,tk)
        VALUES ('$id','$tk')";

// execute the SQL query
if (mysqli_query($con, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($con);
}

  }

						  
			if($_POST["operation"] == 'daily_meal'){
 			    
						    $today = $_POST["today"];
						   echo $today;
						    $meal =mysqli_query($con,"SELECT daily_meal,today_meal FROM meal where created_at = '$today'" );

     
                             if(mysqli_num_rows($meal) > 0){
                               foreach($meal as $row){
                                 $arr=explode(';',$row['daily_meal']);
                    array_pop($arr);
       foreach ($arr as $val) {  
        $each = explode(':',$val);
    $meal = $each[1];
    $id=$each[0];
    
   $each_time = explode(',',$each[1]);
   $breakfast = explode('=',$each_time['0']);
   $launch = explode('=',$each_time['1']);
   $dinner = explode('=',$each_time['2']);
   $guest = explode('=',$each_time['3']);
    
    $yes = '<label class="checkbox-wrap checkbox-primary">
				  					<i class="fa fa-check" aria-hidden="true"></i>
				  					</label>';
    $no = '<label class="checkbox-wrap checkbox-danger">
										  <i class="fa fa-times" aria-hidden="true"></i>
										</label>';
    
    $border =mysqli_query($con,"SELECT * FROM border where unique_id='$id'");

     
                             if(mysqli_num_rows($border) > 0){
                               foreach($border as $r){
    
                                 ?>   
						    <tr class="alert person" role="alert" id="jdjjor">
						    	<td>
						    	  						    	  <?= $r['name']?>(<?= $r['room']?>)
						    	</td>
						      <td>
						        <?php
if($breakfast['1']=='1'){
  echo $yes;
}
else{
  echo $no;
}
?>
						      </td>
						      <td>
						        						        <?php
					        						        
if($launch['1']=='1'){
  echo $yes;
}
else{
  echo $no;
}
?>
						      </td>
<td>						        <?php
if($dinner['1']=='1'){
  echo $yes;
}
else{
  echo $no;
}
?></td>
						      <td class="quantity">
					        	<div class="input-group checkbox-wrap text-primary">
				             	<?= $guest[1]?>
				          	</div>
				          </td>
				            <td class="quantity">
					        	<div class="input-group checkbox-wrap text-primary">
					        	  <?php
					        	  $ar = explode(';',$row['today_meal']);
 array_pop($ar);
					        	  foreach ($ar as $v) {
    $e = explode(':',$v);
    
    if($id==$e[0]){
      echo $e[1];
    }};
    
					        	 ?>
				             
				             	
				          	</div>
				          </td>

						    </tr>
<?php }}} }}


}

if($_POST["operation"] == 'border_tk'){
$id = $_POST["id"];

 ?>
 	<section class="ftco-section">
		<div class="container">
			<div class="row">
				<div class="col-md-12">

					<div class="table-wrap">
						<table class="table">
						  <thead class="thead-primary">
						    <tr>
						    	<th>Date</th>
						      <th>Tk</th>
						    </tr>
						  </thead>
						  <tbody>
						                                 <?php
                             $border =mysqli_query($con,"SELECT * FROM tk where border_id = '$id'");

     
                             if(mysqli_num_rows($border) > 0){
                               foreach($border as $row){
                     ?>   
						    <tr class="alert person" role="alert" id="">
						    	<td>
<?= date('d M Y',strtotime($row['created_at'])); ?>
						      <td><?=$row['tk']?></td>


						    </tr>
		      <?php }} ?>

						  </tbody>
						</table>


					</div>
				</div>
			</div>
		</div>
	</section>
 
 
 
 
 <?php
}
if($_POST["operation"] == 'border_meals'){
$unique_id = $_POST["id"];


 ?>
 
 	<section class="ftco-section">
		<div class="container">
			<div class="row">
				<div class="col-md-12">

					<div class="table-wrap">
						<table class="table">
						  <thead class="thead-primary">
						    <tr>
						    	<th>Date</th>
						      <th>Breakfast</th>
						      <th>Launch</th>
						      <th>Dinner</th>
						      <th>Guest</th>
						      <th>Total</th>
						      
						    </tr>
						  </thead>
<tbody>
 <?php 
  $today = date("Y-m-d");;
						   //echo $today;
						    $meal =mysqli_query($con,"SELECT * FROM meal");

     
                             if(mysqli_num_rows($meal) > 0){
                               foreach($meal as $row){
                                 $arr=explode(';',$row['daily_meal']);
                    array_pop($arr);
       foreach ($arr as $val) {  
        $each = explode(':',$val);
    $meal = $each[1];
    $id=$each[0];
    
    if($id==$unique_id){
   $each_time = explode(',',$each[1]);
   $breakfast = explode('=',$each_time['0']);
   $launch = explode('=',$each_time['1']);
   $dinner = explode('=',$each_time['2']);
   $guest = explode('=',$each_time['3']);
    
    $yes = '<label class="checkbox-wrap checkbox-primary">
				  					<i class="fa fa-check" aria-hidden="true"></i>
				  					</label>';
    $no = '<label class="checkbox-wrap checkbox-danger">
										  <i class="fa fa-times" aria-hidden="true"></i>
										</label>';
    
    ?> 
						    <tr class="alert person" role="alert">
						    	<td>
<?= date('d M Y',strtotime($row['created_at'])); ?>
						    	</td>
						      <td>
						        <?php
if($breakfast['1']=='1'){
  echo $yes;
}
else{
  echo $no;
}
?>
						      </td>
						      <td>
						        						        <?php
					        						        
if($launch['1']=='1'){
  echo $yes;
}
else{
  echo $no;
}
?>
						      </td>
<td>						        <?php
if($dinner['1']=='1'){
  echo $yes;
}
else{
  echo $no;
}
?></td>
						      <td class="quantity">
					        	<div class="input-group checkbox-wrap text-primary">
				             	<?= $guest[1]?>
				          	</div>
				          </td>
				            <td class="quantity">
					        	<div class="input-group checkbox-wrap text-primary">
					        	  <?php
					        	  $ar = explode(';',$row['today_meal']);
 array_pop($ar);
					        	  foreach ($ar as $v) {
    $e = explode(':',$v);
    
    if($id==$e[0]){
      echo $e[1];
    }};
    
					        	 ?>
				             
				             	
				          	</div>
				          </td>

						    </tr>
<?php }} }}
?>

</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</section>
 
 <?php }
if($_POST["operation"] == 'add_shopkeeper'){
 $name = $_POST["name"];
 $tk = $_POST["tk"];
 $date = $_POST["date"];
 $sql = "INSERT INTO shopkeeper (name,tk,created_at)
        VALUES ('$name','$tk','$date')";

// execute the SQL query
if (mysqli_query($con, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($con);
}
 
 
 
}

if($_POST["operation"] == 'extra'){
 $description = $_POST["description"];
 $tk = $_POST["tk"];
 $date = $_POST["date"];
  $sql = "INSERT INTO extra (created_at,description,tk)
        VALUES ('$date','$description','$tk')";
        echo  date("Y-m-d");

// execute the SQL query
if (mysqli_query($con, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($con);
}
 
 
  
 
}
?>

						  




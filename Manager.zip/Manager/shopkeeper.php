<?php include 'include/header.php'; ?>

<section class="ftco-section">
		<div class="container">
			<div class="row">
				<div class="col-md-12">

					<div class="table-wrap">
						<table class="table">
						  <thead class="thead-primary">
						    <tr>
						    	<th>Date</th>
<th>Shopkeeper</th>
						      <th>Tk</th>
						    </tr>
						  </thead>
						  <tbody>
						                                 <?php
                             $border =mysqli_query($con,"SELECT * FROM shopkeeper");

     
                             if(mysqli_num_rows($border) > 0){
                               foreach($border as $row){
                     ?>   
						    <tr class="alert person" role="alert" id="">
						    	<td>
<?= date('d M Y',strtotime($row['created_at'])); ?>
						      <td><?=$row['name']?></td>
						      <td><?=$row['tk']?></td>


						    </tr>
		      <?php }} ?>

						  </tbody>
						</table>


					</div>
				</div>
			</div>
		</div>
	</section>

	




<script>
//const tags = document.getElementsByClassName('tag');
document.querySelector('#add_meal').addEventListener('click',()=>{
  

var person = document.getElementsByClassName('person');
  let id,breakfast,launch,dinner,meal;
  let today_meal='';
  let daily_meal='';
  for(let i=0;i<person.length;i++){
    meal=0;
    id=document.getElementById(person[i].id);
    
    breakfast = id.querySelector('.breakfast');
   launch = id.querySelector('.launch');
    dinner = id.querySelector('.dinner');
    guest = id.querySelector('.guest').value;
    if(breakfast.checked){
      meal+=0.5;
      breakfast='1';
    }
    else{
      breakfast='0';
    }
    if(launch.checked){
      meal+=1;
      launch='1';
    }
    else{
      launch='0';
    }
    if(dinner.checked){
      meal+=1;
      dinner='1';
    }
    else{
      dinner='0';
    }
    meal+=parseInt(guest);
    today_meal += `${person[i].id}:${meal};`;

    daily_meal +=`${person[i].id}:b=${breakfast},l=${launch},d=${dinner},g=${guest};`;
    
    
   }
  var fd = new FormData();
  fd.append('operation','add_meal');
  fd.append('daily_meal',daily_meal);
  fd.append('today_meal',today_meal);
 // alert(today_meal);
  //alert(daily_meal)
  $.ajax({
            url:"ajax/code.php",
              type: 'post',
              data: fd,
              contentType: false,
              processData: false,
              success: function(response){
               alert(response)
                location.reload();
              }
          });
  
})
</script>
  
 



<?php include 'include/footer.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Document</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="assets/css/style.css">
  <link href="assets/assets/css/icons.css" rel="stylesheet" type="text/css"/>

  <link href="assets/assets/css/bootstrap.min.css" rel="stylesheet"/>
  <link rel="stylesheet" href="assets/css/google-font.css">
  <link rel="stylesheet" href="assets/assets/vendors/mdi/css/materialdesignicons.min.css">
  <link href="assets/assets/css/app-style.css" rel="stylesheet"/>
  
  <link rel="shortcut icon" href="assets/assets/images/favicon.png" />
  <link href="assets/assets/css/dataTables.jqueryui.min.css" rel="stylesheet"/>
  <link rel="stylesheet" href="assets/assets/css/style.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</head>
<body id='printableArea' class="bg-theme bg-theme9">
   
   <div class="right-sidebar">
    <div class="switcher-icon">
      <i class="zmdi zmdi-settings zmdi-hc-spin"></i>
    </div>
    <div class="right-sidebar-content">

      <p class="mb-0">Gaussion Texture</p>
      <hr>
      
      <ul class="switcher">
        <li id="theme1"></li>
        <li id="theme2"></li>
        <li id="theme3"></li>
        <li id="theme4"></li>
        <li id="theme5"></li>
        <li id="theme6"></li>
      </ul>

      <p class="mb-0">Gradient Background</p>
      <hr>
      
      <ul class="switcher">
        <li id="theme7"></li>
        <li id="theme8"></li>
        <li id="theme9"></li>
        <li id="theme10"></li>
        <li id="theme11"></li>
        <li id="theme12"></li>
		<li id="theme13"></li>
        <li id="theme14"></li>
        <li id="theme15"></li>
      </ul>
      
     </div>
   </div>


<div id='' class="container-fluid px-4 mt-4">
    
    
    <div class="row">
        <div class="col-md-12">
            <div class="card">

                 
                <div class="card-body">
                    
                     <div class="table-responsive">

                     </div>
                </div>
                <div style='display:one' class="hide card-footer">
                      <button onclick="printDiv('printableArea')"class='hide'>Create PDF</button>

    </div>
            </div>
        </div>
    </div>
</div>

	<?php
	
	//include 'include/addtk.php'; ?>

<style>
  @media print {
.hide{
  display:none;
}
.print{
  color:black;
}
th{
  color:green;
}
}
  
</style>

<script>
  function printDiv(divId) {
    var printContents = document.getElementById(divId).innerHTML;
    var originalContents = document.body.innerHTML;

    document.body.innerHTML = printContents;
    window.print();

    document.body.innerHTML = originalContents;

     
}

</script>




    

  <script src="assets/assets/js/jquery.min.js"></script>
  <script src="assets/assets/js/bootstrap.min.js"></script>
  <script src="assets/assets/js/sidebar-menu.js"></script>
  <script src="assets/assets/js/app-script.js"></script>

  <script src="assets/assets/js/off-canvas.js"></script>
  <script src="assets/assets/js/misc.js"></script>
  <script src="assets/assets/js/dashboard.js"></script>
  
  <script type="text/javascript" src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="assets/assets/js/jquery.dataTables.min.js"></script>
  <script src="assets/assets/js/dataTables.jqueryui.min.js"></script>
  <script>    
 
    var fd = new FormData();
  fd.append('operation','print');
   $.ajax({
            url:"ajax/print.php",
              type: 'post',
              data: fd,
              contentType: false,
              processData: false,
              success: function(response){
               $('.table-responsive').html(response);
                
           
           $('.table').DataTable({
             displayLength: 50
           });/**/
        
   //     addModal();
        
        
        
              }
          });

        </script>
</body>
</html>
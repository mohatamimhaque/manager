<?php include 'include/header.php';?>
<?php include 'include/calender.php';?>



	<section class="ftco-section">
		<div class="container">
			<div class="row">
				<div class="col-md-12">

					<div class="table-wrap">
						<table class="table">
						  <thead class="thead-primary">
						    <tr>
						    	<th>Name</th>
						      <th>Breakfast</th>
						      <th>Launch</th>
						      <th>Dinner</th>
						      <th>Guest</th>
						      <th>Total</th>
						      
						    </tr>
						  </thead>
<tbody>
  
</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</section>


<script>

var today = new Date();
var year = today.getFullYear();
var month = String(today.getMonth() + 1).padStart(2, '0'); // Months are zero-based
var day = String(today.getDate()).padStart(2, '0');

var formattedDate = year + '-' + month + '-' + day;
dailyMeal(formattedDate);
function dailyMeal(day){
  var fd = new FormData();
  fd.append('operation','daily_meal');
  fd.append('today',day);
  
$.ajax({
    url:"ajax/code.php",
              type: 'post',
              data: fd,
              contentType: false,
              processData: false,
              success: function(response){
               $('tbody').html(response);
           // alert(response)
              }
          });
}
</script>

 <script src="assets/js/vue.min.js"></script> 
   <script src="assets/js/moment.min.js"></script> 
      <script src="assets/js/calender.js"></script> 

<?php include 'include/footer.php';?>

